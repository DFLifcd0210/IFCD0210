<?php
/*
    http://localhost/dia03/quiniela.php
    
    Generar 15 resultados de la quiniela
    Los resultados posibles son: 1 X 2   
*/

    for ($partido=1; $partido<=15; $partido++) {
        
        $resultado = rand(1, 3);
        
        if ($resultado == 3) {
            $resultado = "X";
        }
        
        echo "El resultado del partido $partido es $resultado<br>";
        
    }