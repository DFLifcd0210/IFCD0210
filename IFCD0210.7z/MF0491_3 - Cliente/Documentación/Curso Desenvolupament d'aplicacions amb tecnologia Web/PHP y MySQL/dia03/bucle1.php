<?php
/*
    http://localhost/dia03/bucle1.php
*/
    for ($i=0; $i<1000; $i++) {
        echo "Kilian Jornet es un crack<br>";
    }

?>