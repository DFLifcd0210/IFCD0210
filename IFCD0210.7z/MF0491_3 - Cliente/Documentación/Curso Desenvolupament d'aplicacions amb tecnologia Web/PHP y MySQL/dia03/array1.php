<?php
/*
    http://localhost/dia03/array1.php

*/

   $alumnos = array(
        "Alcides",
        "Alex",
        "Angel",
        "Bryan",
        "Paola",
        "David",
        "Francesc",
        "Josep Maria",
        "Julio",
        "Katiuzka",
        "Laura",
        "Miguel",
        "Rebeca",   
   );
   
   /*
   // Versión 1.0
   echo $alumnos[0].'<br>';
   echo $alumnos[1].'<br>';
   echo $alumnos[2].'<br>';
   echo $alumnos[3].'<br>';
   echo $alumnos[4].'<br>';
   echo $alumnos[5].'<br>';
   echo $alumnos[6].'<br>';
   echo $alumnos[7].'<br>';
   echo $alumnos[8].'<br>';
   echo $alumnos[9].'<br>';
   echo $alumnos[10].'<br>';
   echo $alumnos[11].'<br>';
   echo $alumnos[12].'<br>';
   */
   
   /*
   // Versión 2.0
   for ($i=0; $i<13; $i++) {
       echo $alumnos[$i].'<br>';
   }
   */
   
   /*
   // Versión 3.0
   for ($i=0; $i<count($alumnos); $i++) {
       echo $alumnos[$i].'<br>';
   }
   */
   
   /*
   // Versión 3.5
   for ($i=0; $i<count($alumnos); $i++) {
       $nombre = $alumnos[$i];
       echo "$nombre<br>";
   }
   */
   
   // Versión 4.0
   foreach ($alumnos as $nombre) {
       echo "$nombre<br>";
   }
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   

   
   
   
   
   
   