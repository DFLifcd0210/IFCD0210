<?php
/*
    http://localhost/dia03/primitiva.php
    
    Generar 6 números de la primitiva
    Los números están entre 1 y 49
    
    
*/

    for ($cuenta=0; $cuenta<6; $cuenta++) {
        
        $primitiva = rand(1, 49);
        
        echo "$primitiva, ";
        
    }