<?php
/*
    http://localhost/dia03/bucle3.php
    
    Imprimir del 10 al 100 
*/
    for ($cuenta=10; $cuenta<=100; $cuenta++) {
        echo "$cuenta<br>";
    }

?>