<?php
/*
  http://localhost/dia03/while3.php
  
*/
    $asteriscos = "*";
    
    while ($asteriscos != "*****************") {
       
        echo $asteriscos . '<br>';
       
        $asteriscos = $asteriscos . "*";
    }

?>