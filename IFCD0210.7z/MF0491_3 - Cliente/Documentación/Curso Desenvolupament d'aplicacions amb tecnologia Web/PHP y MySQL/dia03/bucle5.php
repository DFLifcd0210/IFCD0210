<?php
/*
    http://localhost/dia03/bucle5.php
    
    Mostrar números pares entre 0 y 100
        
    $par++;
    $par = $par + 1;
    
    $par += 2;
    $par = $par + 2;
    
*/
    for ($par=0; $par<=100; $par += 2) {
        echo "$par<br>";        
    }

?>