<?php
/*
  http://localhost/dia03/multiplicar.php
  
  La tabla de multiplicar del 5  
    1 x 5 = 5
    2 x 5 = 10
    3 x 5 = 15
    ...
    10 x 5 = 50  
*/

    /*
    // Versión 1.0
    for ($numero=1; $numero<=10; $numero++) {        
        echo "$numero<br>";        
    }
    */
    
    /*
    // Versión 2.0
    for ($numero=1; $numero<=10; $numero++) {        
        echo "$numero x 5 = <br>";        
    }
    */
    
    /*
    // Versión 3.0
    for ($numero=1; $numero<=10; $numero++) {   
        $producto = $numero * 5;
        echo "$numero x 5 = $producto<br>";        
    }
    */
    
    // Versión 4.0
    $tabla = 7;
    for ($numero=1; $numero<=10; $numero++) {   
        $producto = $numero * $tabla;
        echo "$numero &times; $tabla = $producto<br>";        
    }
   
    
    
    
    
    
    