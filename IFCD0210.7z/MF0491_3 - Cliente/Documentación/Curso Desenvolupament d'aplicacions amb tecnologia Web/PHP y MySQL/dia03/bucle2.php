<?php
/*
    http://localhost/dia03/bucle2.php
*/
    for ($num=0; $num<1000; $num++) {
        echo "$num<br>";
    }

?>