<?php

	$ruedas = 3;
	
	if ($ruedas == 1) {
		echo "Monociclo<br>";
	}
	elseif ($ruedas == 2) {
		echo "Bicicleta<br>";
	}
	elseif ($ruedas == 3) {
		echo "Triciclo<br>";
	}
	elseif ($ruedas == 4) {
		echo "Coche<br>";
	}
	elseif ($ruedas == 5) {
		echo "Silla de despacho<br>";
	}
	elseif ($ruedas == 6) {
		echo "Robot marciano<br>";
	}
	else {
		echo "Vehículo desconocido<br>";
	}
	
	switch ($ruedas) {
		case 1: echo "Monociclo<br>"; break;
		case 2: echo "Bicicleta<br>"; break;
		case 3: echo "Triciclo<br>"; break;
		case 4: echo "Coche<br>"; break;
		case 5: echo "Silla de despacho<br>"; break;
		case 6: echo "Robot marciano<br>"; break;
		default: echo "Vehículo desconocido<br>";
	}
 
?>	
