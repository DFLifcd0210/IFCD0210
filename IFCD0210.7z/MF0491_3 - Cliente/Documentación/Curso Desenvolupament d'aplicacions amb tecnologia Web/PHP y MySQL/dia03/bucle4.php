<?php
/*
    http://localhost/dia03/bucle4.php
    
    Cuenta atrás del 10 al 0
*/
    for ($cuenta=10; $cuenta>=0; $cuenta--) {
        if ($cuenta == 0) {
            echo "Ignición!!!<br>";
        }
        else {
            echo "$cuenta<br>";
        }
    }

?>