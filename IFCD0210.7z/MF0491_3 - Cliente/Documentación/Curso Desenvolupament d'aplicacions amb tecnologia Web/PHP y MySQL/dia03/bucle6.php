<?php
/*
    http://localhost/dia03/bucle6.php
    
    Mostrar números impares entre 99 y 1 en orden descendente
*/
    for ($impar = 99; $impar>=1; $impar -= 2) {
        echo "$impar<br>";        
    }

?>