<?php
/*
  http://localhost/dia03/while1.php
  
  for ($cuenta=1; $cuenta<=10; $cuenta++) {
      echo "$cuenta<br>";
  } 
  
*/

    $cuenta = 1;
    
    while ($cuenta <= 10) {
        
        echo "$cuenta<br>";
        
        $cuenta++;        
    }

?>