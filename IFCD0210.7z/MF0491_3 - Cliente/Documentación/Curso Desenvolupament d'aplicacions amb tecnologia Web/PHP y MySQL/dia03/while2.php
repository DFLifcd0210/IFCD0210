<?php
/*
  http://localhost/dia03/while2.php
  
*/
    $numero = 1000000;
    
    while ($numero > 1) {
        
        echo "$numero<br>";
        
        $numero = $numero / 2;   // $numero /= 2;   
    }

?>