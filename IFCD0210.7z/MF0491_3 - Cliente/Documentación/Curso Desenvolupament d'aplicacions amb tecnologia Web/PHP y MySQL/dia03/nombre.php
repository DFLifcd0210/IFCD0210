<?php
/*
   http://localhost/dia03/nombre.php
   http://localhost/dia03/nombre.php?apodo=   
   http://localhost/dia03/nombre.php?apodo=Pepe

    Si está puesto el parámetro GET apodo
      Si no hay nada en el apodo
        muestra que no hay nada
      y sino
        muestra el parámetro GET apodo
    y sino
      muestra que falta el parámetro GET apodo
*/    
    if (isset($_GET['apodo'])) {
        if (empty($_GET['apodo'])) {
            echo "No tienes nombre";
        }
        else {
            echo "Te llamas ".$_GET['apodo'];
        }    
    }
    else {
        echo "Falta el parámetro GET apodo";
    }

?>