<?php
/*
    http://localhost/dia03/primitiva2.php
    
    Generar 100 primitivas 
    
    Usar FOR ANIDADO
    
    
*/
    for ($repetir=1; $repetir<=100; $repetir++) {

        for ($cuenta=0; $cuenta<6; $cuenta++) {        
            $primitiva = rand(1, 49);        
            echo "$primitiva, ";        
        }
        echo "<br>";
        
    }