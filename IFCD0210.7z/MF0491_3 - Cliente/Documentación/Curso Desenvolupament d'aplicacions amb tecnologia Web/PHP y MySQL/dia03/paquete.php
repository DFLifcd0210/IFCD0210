<?php
    //   http://localhost/dia03/paquete.php
    
    $urgente = false; // true, false
    $peso = 2.5; // kilogramos
    
    if ($urgente) {
        echo "Es urgente";
        $precio = 10; // Euros por kgr.
    }
    else {
        echo "No es urgente";
        if ($peso >= 0 && $peso < 2) {
            $precio = 5;
        }
        elseif ($peso >= 2 && $peso < 10) {
            $precio = 4;
        }
        else {
            $precio = 3;
        }        
    }
    
    $total = $peso * $precio;
    echo " y pesa $peso kgrs entonces el precio es $precio €/Kgrs y el total es $total euros";