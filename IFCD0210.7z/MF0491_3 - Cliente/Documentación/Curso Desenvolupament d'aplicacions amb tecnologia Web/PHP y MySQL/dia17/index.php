<?php
    require_once('../template.php');
?><!DOCTYPE html>
<html>
<head>
<meta charset="utf-8" />
<title>PHP 17</title>
</head>
<body>
<h1>PHP 17</h1>
<h2>Tabla noticias: Gestor para modificar</h2>
<ul>
    <li><?php enlazar('noticias_ejercicio.txt', 'Enunciado del ejercicio'); ?></li>
    <li><?php enlazar('noticias.sql', 'Base de datos'); ?></li>
    <li><?php enlazar('noticias.php', 'Página pública'); ?></li>
    <li><?php enlazar('noticias.css', 'Estilos'); ?></li>
    <li><?php enlazar('cambiar_noticias.php', 'Cambiar noticias'); ?></li>
</ul>

</body>
</html>
