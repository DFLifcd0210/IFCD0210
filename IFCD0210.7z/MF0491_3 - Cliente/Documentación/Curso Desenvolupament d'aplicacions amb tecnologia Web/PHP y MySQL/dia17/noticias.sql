-- noticias.sql
/*
    Pasos a seguir:
        - Abrir el http://localhost/phpmyadmin
        - Seleccionar la base de datos bdacme
        - Pulsar en Importar, Examinar, Continuar.
        - Comprobar que existe la tabla y los datos
*/

CREATE TABLE noticias(
    id         INT AUTO_INCREMENT,
    titulo     VARCHAR(128) NOT NULL,
    contenido  TEXT NOT NULL,
    enlace     VARCHAR(128),
    PRIMARY KEY (id)
);

INSERT INTO noticias(id, titulo, contenido, enlace)
VALUES
    (1, 'Primera', 'Cosas que pasan cerca de casa', 'http://www.google.com/'),
    (2, 'Segunda', 'Otras cosas de la región', 'http://es.wikipedia.org/'),
    (3, 'Tercera', 'Noticas a nivel nacional', 'http://php.net/docs'),
    (4, 'Cuarta', 'Noticias internacionales', 'http://mysql.com/dev');