<?php
    // http://localhost/dia17/noticias.php

    // 1) Inicializar las variables
    $titulo1 = $titulo2 = $titulo3 = $titulo4 = '';
    $contenido1 = $contenido2 = $contenido3 = $contenido4 = '';
    $enlace1 = $enlace2 = $enlace3 = $enlace4 = '';

    require_once "../conexion.php";
    $acme = new PDO("mysql:host=$servidor;dbname=$basedatos", $usuario, $clave);
    $acme->exec("SET CHARACTER SET utf8");

    $plantilla = $acme->prepare("SELECT * FROM noticias WHERE id = ?");

    $plantilla->execute(array(1));
    $datos = $plantilla->fetch(); // Recupera sólo la primera fila
    $titulo1 = $datos['titulo'];
    $contenido1 = $datos['contenido'];
    $enlace1 = $datos['enlace'];

    $plantilla->execute(array(2));
    $datos = $plantilla->fetch();
    $titulo2 = $datos['titulo'];
    $contenido2 = $datos['contenido'];
    $enlace2 = $datos['enlace'];

    $plantilla->execute(array(3));
    $datos = $plantilla->fetch();
    $titulo3 = $datos['titulo'];
    $contenido3 = $datos['contenido'];
    $enlace3 = $datos['enlace'];

    $plantilla->execute(array(4));
    $datos = $plantilla->fetch();
    $titulo4 = $datos['titulo'];
    $contenido4 = $datos['contenido'];
    $enlace4 = $datos['enlace'];

?><!DOCTYPE html>
<html>
<head>
  <title>Noticias</title>
  <meta charset="utf-8" />
  <link href="noticias.css" rel="stylesheet" />
</head>
<body>
  <header>
    <h1>Noticias</h1>
  </header>
  <section>
    <article>
        <h2><?php echo htmlspecialchars($titulo1); ?></h2>
        <p><?php echo htmlspecialchars($contenido1); ?></p>
        <p><a href="<?php echo $enlace1; ?>">Enlace</a></p>
    </article>
    <article>
        <h2><?php echo htmlspecialchars($titulo2); ?></h2>
        <p><?php echo htmlspecialchars($contenido2); ?></p>
        <p><a href="<?php echo $enlace2; ?>">Enlace</a></p>
    </article>
    <article>
        <h2><?php echo htmlspecialchars($titulo3); ?></h2>
        <p><?php echo htmlspecialchars($contenido3); ?></p>
        <p><a href="<?php echo $enlace3; ?>">Enlace</a></p>
    </article>
    <article>
        <h2><?php echo htmlspecialchars($titulo4); ?></h2>
        <p><?php echo htmlspecialchars($contenido4); ?></p>
        <p><a href="<?php echo $enlace4; ?>">Enlace</a></p>
    </article>
  </section>
  <footer>
    <p>Acme &copy; 2015</p>
  </footer>
</body>
</html>
