CREATE TABLE articulos(
    id INT AUTO_INCREMENT,
    articulo VARCHAR(64) NOT NULL,
    precio DECIMAL(8,2) DEFAULT 0,
    id_tipo INT,
    descripcion TEXT,
    PRIMARY KEY (id),
    UNIQUE KEY (articulo),
    KEY (id_tipo)
);

CREATE TABLE tipos(
    id INT AUTO_INCREMENT,
    tipo VARCHAR(32),
    PRIMARY KEY (id),
    UNIQUE KEY (tipo)
);

INSERT INTO tipos(id, tipo) 
VALUES 
  (1, 'Primavera'),
  (2, 'Verano'),
  (3, 'Otoño'),
  (4, 'Invierno');

INSERT INTO articulos(articulo, precio, id_tipo, descripcion) 
VALUES 
  ('uno', 10, 4, 'Artículo 1'), 
  ('dos', 20, 2, 'Artículo 2');
  
-- Integridad referencial
ALTER TABLE articulos
  ADD FOREIGN KEY (id_tipo) REFERENCES tipos(id);