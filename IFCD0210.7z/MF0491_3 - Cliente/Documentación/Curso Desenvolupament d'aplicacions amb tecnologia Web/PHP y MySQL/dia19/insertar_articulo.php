<?php
    // http://localhost/php/dia19/insertar_articulo.php

    require_once "../conexion.php";
    $acme = new PDO("mysql:host=$servidor;dbname=$basedatos", $usuario, $clave);
    $acme->exec("SET CHARACTER SET utf8");

    // Inicializar las variables que se muestran en el HTML
    $mensaje = '';

    // Corresponde con campos de la tabla articulos
    $articulo = '';
    $precio = '';
    $id_tipo = '';
    $descripcion = '';

    // Obtener los tipos
    $tipos = $acme->query("SELECT id, tipo FROM tipos ORDER BY tipo");

    if (!empty($_POST)) {

        // Recuperar los datos introducidos por el usuario
        $articulo    = trim($_POST['articulo']);
        $precio      = trim($_POST['precio']);
        $id_tipo   = intval($_POST['id_tipo']);
        $descripcion = trim($_POST['descripcion']);

        // Comprobar que los datos sean correctos
        if (empty($articulo))   { $mensaje .= 'Falta el artículo<br>'; }
        if (empty($precio))     { $mensaje .= 'Falta el precio<br>'; }
        if (empty($id_tipo))    { $mensaje .= 'Falta el tipo<br>'; }
        if (empty($descripcion)){ $mensaje .= 'Falta la descripción<br>'; }

        // Si no hay mensaje de error insertamos el artículo en la BD
        if (empty($mensaje)) {
            $plantilla = $acme->prepare("INSERT INTO articulos(articulo, precio, id_tipo, descripcion) VALUES (?,?,?,?)");
            if ($plantilla->execute(array($articulo, $precio, $id_tipo, $descripcion))) {
               header("Location: gestor_articulos.php");
            }
            else {
               $mensaje = "ERROR: No pude insertar";
            }
        }
    }

?><!DOCTYPE html>
<html>
<head>
  <title>Insertar artículo</title>
  <meta charset="utf-8" />
  <link href="privado.css" rel="stylesheet" />
</head>
<body>
    <h1>Insertar artículo</h1>

    <p><?php echo $mensaje; ?></p>

    <form action="insertar_articulo.php" method="post">
       <p>
          <label>Artículo</label>
          <input type="text" name="articulo" value="<?php echo htmlspecialchars($articulo); ?>" />
       <p>
       <p>
          <label>Precio</label>
          <input type="text" name="precio" value="<?php echo $precio; ?>"/>
       </p>
       <p>
          <label>Tipo</label>
          <select name="id_tipo">
            <option></option>
            <?php
              foreach($tipos as $fila) {
                echo "<option value=\"$fila[id]\">$fila[tipo]</option>";
              }
            ?>
          </select>
       <p>
       <p>
          <label>Descripción</label>
          <textarea name="descripcion"><?php echo htmlspecialchars($descripcion); ?></textarea>
       </p>
       <p>
          <input type="submit" value="Insertar" />
       </p>
    </form>

    <p><a href="gestor_articulos.php">Gestor de artículos</a></p>

</body>
</html>
