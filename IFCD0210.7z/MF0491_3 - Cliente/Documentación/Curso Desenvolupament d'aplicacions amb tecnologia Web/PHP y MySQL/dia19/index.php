<?php
    require_once('../template.php');
?><!DOCTYPE html>
<html>
<head>
<meta charset="utf-8" />
<title>PHP 19</title>
</head>
<body>
<h1>PHP 19</h1>
<h2>Tabla artículos: Gestor de contenidos completo</h2>
<p>Tiene un campo con lista deplegable</p>
<ul>
    <li><?php enlazar('articulos_ejercicio.txt', 'Enunciado del ejercicio'); ?></li>
    <li><?php enlazar('articulos.sql', 'Base de datos'); ?></li>
    <li><?php enlazar('articulos.php', 'Página pública'); ?></li>
    <li><?php enlazar('articulos.css', 'Estilos'); ?></li>
    <li><?php enlazar('gestor_articulos.php', 'Gestor de artículos'); ?></li>
    <li><?php enlazar('insertar_articulo.php', 'Insertar nuevo artículo'); ?></li>
    <li><?php enlazar('borrar_articulo.php', 'Borrar artículo existente'); ?></li>
    <li><?php enlazar('modificar_articulo.php', 'Modificar un artículo'); ?></li>
</ul>

</body>
</html>
