<?php
    // http://localhost/php/dia19/modificar_articulo.php

    require_once "../conexion.php";
    $acme = new PDO("mysql:host=$servidor;dbname=$basedatos", $usuario, $clave);
    $acme->exec("SET CHARACTER SET utf8");

    // Inicializar las variables que se muestran en el HTML
    $mensaje = '';

    // Variables de los campos de la tabla artículos
    $id = '';
    $articulo = '';
    $precio = '';
    $id_tipo = '';
    $descripcion = '';

    // Obtener los tipos para rellenar la lista desplegable del formulario
    $tipos = $acme->query("SELECT id, tipo FROM tipos ORDER BY tipo");

    if (!empty($_GET)) { // Vengo del gestor de contenidos
        $id = $_GET['id'];

        // Recuperar la información de la base datos
        $plantilla = $acme->prepare('SELECT * FROM articulos WHERE id = ?');
        $plantilla->execute(array($id));
        $datos = $plantilla->fetch();

        // Recuperar la primera fila
        $articulo = $datos['articulo'];
        $precio = $datos['precio'];
        $id_tipo = $datos['id_tipo'];
        $descripcion = $datos['descripcion'];
    }
    elseif (!empty($_POST)) { // He pulsado el botón del formulario

        // Recuperar los datos introducidos por el usuario
        $id = $_POST['id'];
        $articulo    = trim($_POST['articulo']);
        $precio      = trim($_POST['precio']);
        $id_tipo   = intval($_POST['id_tipo']);
        $descripcion = trim($_POST['descripcion']);

        // Comprobar que los datos sean correctos
        if (empty($articulo))   { $mensaje .= 'Falta el artículo<br>'; }
        if (empty($precio))     { $mensaje .= 'Falta el precio<br>'; }
        if (empty($id_tipo))    { $mensaje .= 'Falta el tipo<br>'; }
        if (empty($descripcion)){ $mensaje .= 'Falta la descripción<br>'; }

        // Si no hay mensaje de error modificar el artículo en la BD
        if (empty($mensaje)) {
            $plantilla = $acme->prepare("UPDATE articulos SET articulo = ?, precio = ?, id_tipo = ?, descripcion = ? WHERE id = ?");
            if ($plantilla->execute(array($articulo, $precio, $id_tipo, $descripcion, $id))) {
               $mensaje = "Actualización realizada correctamente";
            }
            else {
               $mensaje = "ERROR: No pude modificar";
            }
        }
    }
    else {
        $mensaje = "ERROR: Falta el id";
    }

?><!DOCTYPE html>
<html>
<head>
  <title>Modificar artículo</title>
  <meta charset="utf-8" />
  <link href="privado.css" rel="stylesheet" />
</head>
<body>
    <h1>Modificar artículo</h1>

    <p><?php echo $mensaje; ?></p>

    <form action="modificar_articulo.php" method="post">
      <input type="hidden" name="id" value="<?php echo $id; ?>" />
      <p>
          <label>Artículo</label>
          <input type="text" name="articulo" value="<?php echo htmlspecialchars($articulo); ?>" />
       <p>
       <p>
          <label>Precio</label>
          <input type="text" name="precio" value="<?php echo $precio; ?>"/>
       </p>
       <p>
          <label>Tipo</label>
          <select name="id_tipo">
            <option></option>
            <!--
            <option value="1">Primavera</option>
            <option value="2"  >Verano</option>
            <option value="3">Otoño</option>
            <option value="4" selected>Invierno</option>
            -->
            <?php
              foreach($tipos as $fila) {
                $selected = '';
                if ($fila['id'] == $id_tipo) {
                  $selected = 'selected';
                }

                echo "<option value=\"$fila[id]\" $selected>$fila[tipo]</option>";
              }
            ?>
          </select>
       <p>
       <p>
          <label>Descripción</label>
          <textarea name="descripcion"><?php echo htmlspecialchars($descripcion); ?></textarea>
       </p>
       <p>
          <input type="submit" value="Modificar" />
       </p>
    </form>

    <p><a href="gestor_articulos.php">Gestor de artículos</a></p>

</body>
</html>
