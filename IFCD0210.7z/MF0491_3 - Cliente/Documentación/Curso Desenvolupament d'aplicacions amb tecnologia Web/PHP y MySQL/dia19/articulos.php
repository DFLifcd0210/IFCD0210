<?php
    // http://localhost/dia19/articulos.php
    $datos = array();

    require_once "../conexion.php";
    $acme = new PDO("mysql:host=$servidor;dbname=$basedatos", $usuario, $clave);
    $acme->exec("SET CHARACTER SET utf8");

    $datos = $acme->query("SELECT a.articulo, a.precio, t.tipo, a.descripcion FROM articulos a INNER JOIN tipos t ON a.id_tipo = t.id ORDER BY a.articulo");

?><!DOCTYPE html>
<html>
<head>
  <title>Artículos</title>
  <meta charset="utf-8" />
  <link href="articulos.css" rel="stylesheet" />
</head>
<body>
  <header>
    <h1>Artículos</h1>
  </header>
  <section>
    <?php foreach($datos as $fila): ?>
    <article>
        <h2><?php echo htmlspecialchars($fila['articulo']); ?></h2>
        <p><?php echo $fila['precio']; ?> €</p>
        <p><?php echo htmlspecialchars($fila['tipo']); ?></p>
        <p><?php echo htmlspecialchars($fila['descripcion']); ?></p>
    </article>
    <?php endforeach; ?>
  </section>
  <footer>
    <p>Acme &copy; 2015</p>
  </footer>
</body>
</html>
