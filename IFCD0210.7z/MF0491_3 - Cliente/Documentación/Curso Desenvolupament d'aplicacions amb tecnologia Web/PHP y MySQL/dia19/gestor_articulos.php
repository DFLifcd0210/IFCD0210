<?php
    // http://localhost/php/dia19/gestor_articulos.php

    $datos = array();

    require_once "../conexion.php";
    $acme = new PDO("mysql:host=$servidor;dbname=$basedatos", $usuario, $clave);
    $acme->exec("SET CHARACTER SET utf8");

    $datos = $acme->query("SELECT * FROM articulos ORDER BY articulo");

?><!DOCTYPE html>
<html>
<head>
  <title>Gestor de artículos</title>
  <meta charset="utf-8" />
  <link href="privado.css" rel="stylesheet" />
</head>
<body>
    <h1>Gestor de artículos</h1>
    <table>
    <tr>
        <th>Artículo</th>
        <th>Precio</th>
        <th>Comandos</th>
    </tr>
    <?php foreach($datos as $fila): ?>
      <tr>
        <td><?php echo htmlspecialchars($fila['articulo']); ?></td>
        <td><?php echo $fila['precio']; ?> €</td>
        <td>
            <a href="modificar_articulo.php?id=<?php echo $fila['id']; ?>">Modificar</a> |
            <a href="borrar_articulo.php?id=<?php echo $fila['id']; ?>">Borrar</a>
        </td>
      </tr>
    <?php endforeach; ?>
    </table>
    <p>
        <a href="insertar_articulo.php">Insertar un nuevo artículo</a>
    </p>
    <p>
        <a href="articulos.php">Ver página pública</a>
    </p>
</body>
</html>
