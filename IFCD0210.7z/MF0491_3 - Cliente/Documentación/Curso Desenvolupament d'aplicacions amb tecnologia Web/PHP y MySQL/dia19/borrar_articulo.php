<?php
    // http://localhost/php/dia18/borrar_articulo.php

    require_once "../conexion.php";
    $acme = new PDO("mysql:host=$servidor;dbname=$basedatos", $usuario, $clave);
    $acme->exec("SET CHARACTER SET utf8");

    // Inicializar las variables que se muestran en el HTML
    $mensaje = '';
    $id = '';
    $articulo = ''; // Variable del nombre del artículo

    if (!empty($_GET)) { // Vengo del gestor de contenidos
        $id = $_GET['id'];

        // Recuperar el nombre del artículo a partir del id
        $plantilla = $acme->prepare("SELECT articulo FROM articulos WHERE id = ?");
        $plantilla->execute(array($id));
        $fila = $plantilla->fetch();
        $articulo = $fila['articulo'];
    }
    elseif (!empty($_POST)) { // He pulsado el botón del formulario
        $id = $_POST['id'];
        $plantilla = $acme->prepare("DELETE FROM articulos WHERE id = ?");
        if ($plantilla->execute(array($id))) {
            header("Location: gestor_articulos.php");
        }
        else {
            $mensaje = "ERROR: No pude borrar";
        }
    }
    else {
        $mensaje = "ERROR: Falta el id";
    }

?><!DOCTYPE html>
<html>
<head>
  <title>Borrar artículo</title>
  <meta charset="utf-8" />
  <link href="privado.css" rel="stylesheet" />
</head>
<body>
    <h1>Borrar artículo</h1>

    <p><?php echo $mensaje; ?></p>

    <form action="borrar_articulo.php" method="post">
       <input type="hidden" name="id" value="<?php echo $id; ?>" />
       <p>
          <?php echo htmlspecialchars($articulo); ?>
       </p>
       <p>
          <input type="submit" value="Borrar" />
       </p>
    </form>

    <p><a href="gestor_articulos.php">Gestor de artículos</a></p>
</body>
</html>
