<?php
    require_once('../template.php');
?><!DOCTYPE html>
<html>
<head>
<meta charset="utf-8" />
<title>PHP 14</title>
</head>
<body>
<h1>PHP 14</h1>
<h2>Bases de datos con mediante PDO</h2>
<h3>Contador</h3>
<ul>
    <li><?php enlazar('contador.php', 'Contador de visitas', 'Tabla contadores'); ?></li>
    <li><?php enlazar('contador2.php', 'Ídem en página HTML', 'Uso de include'); ?></li>
</ul>
<h3>Comentarios</h3>
<ul>
    <li><?php enlazar('comentarios1.php', 'Parámetros SQL', 'Métodos: prepare, execute y fetch'); ?></li>
    <li><?php enlazar('comentarios2.php', 'Formulario para insertar comentarios'); ?></li>
    <li><?php enlazar('comentarios3.php', 'Ídem con control de palabrotas'); ?></li>
</ul>
</body>
</html>
