<?php
/*
    Contador de visitas a la página web
    http://localhost/dia14/contador.php

    EJERCICIO:

    a) Crear una tabla de contadores
      - id       - Número entero, autonumérico y clave principal
      - contador - Número entero por omisión vale 0
      - concepto - Texto de 16 y clave única

    b) Insertar el contador de visitas (concepto: visitas)

    c) Incrementar el contador de visitas en 1 unidad

    d) Mostrar el contador de visitas
*/

/*
    Prueba de ejecutar el código indicado en el try
    y si se produce algún error salta al catch que está abajo
*/
try {

    /*
        1) Conectar con la BD

        acme es un objeto de la clase PDO (la clase ya viene dentro de PHP)
        Si se hace new se está llamando al constructor de PDO.
        El constructor de la clase PDO tiene tres argumentos:
          1º Cadena de conexión:
                Servidor de la base de datos: localhost
                Nombre de la base de datos
          2º Nombre de usuario a la BD
          3º Contraseña
    */
    //$acme = new PDO("mysql:host=localhost;dbname=bdacme", 'bdacme', 'bdacme');
    require_once "../conexion.php";
    $acme = new PDO("mysql:host=$servidor;dbname=$basedatos", $usuario, $clave);

    /*
        2) Mensaje codificados en Unicode
    */
    $acme->exec("SET CHARACTER SET utf8");

    /*
        3) Crear la tabla

        Se podría hacer este paso con el phpMyAdmin
    */
    $acme->exec("CREATE TABLE contadores(
        id INT AUTO_INCREMENT,
        concepto VARCHAR(16) NOT NULL,
        contador INT DEFAULT 0,
        PRIMARY KEY (id),
        UNIQUE KEY (concepto)
    )");

    /*
        4) Añadir el contador

        Se podría hacer este paso con el phpMyAdmin
    */
    $acme->exec("INSERT INTO contadores(id,concepto,contador) VALUES
      (1, 'visitas', 0),
      (2, 'premios', 0),
      (3, 'concursos', 0)
    ");

    /*
        5) Incrementar el contador de visitas
    */
    $acme->exec("UPDATE contadores
        SET contador = contador + 1
        WHERE concepto = 'visitas'
    ");

    /*
        6) Mostrar el contador
    */
    $datos = $acme->query("SELECT contador
    FROM contadores
    WHERE concepto = 'visitas' ");

    foreach ($datos as $fila) {
        echo $fila['contador'];
    }

}
catch (Exception $ex) {
        echo "<h2>Se ha producido una excepción</h2>";
        echo "<p>".$ex->getMessage()."</p>";
}
