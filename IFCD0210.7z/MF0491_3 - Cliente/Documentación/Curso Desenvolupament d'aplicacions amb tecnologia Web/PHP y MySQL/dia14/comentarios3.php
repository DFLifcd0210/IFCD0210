<?php
/*
    http://localhost/dia14/comentarios3.php
*/
    require_once "../conexion.php";
    $acme = new PDO("mysql:host=$servidor;dbname=$basedatos", $usuario, $clave);
    $acme->exec("SET CHARACTER SET utf8");

    $palabrotas = array('caspitas', 'recorcholis', 'mecachis', 'tronco',
        'julandron', 'julai', 'gañan');
    $malhablado = false;

    if (!empty($_POST)) {
        $comentario = strtolower($_POST['comment']);
        foreach($palabrotas as $palabrota) {
            if (strpos($comentario, $palabrota) !== false) {
                $malhablado = true;
                break;
            }
        }

        if (!$malhablado) {
            $plantilla = $acme->prepare("INSERT INTO comentarios(usuario,comentario)
                VALUES (?, ?)");
            $plantilla->execute(array( $_POST['user'], $_POST['comment'] ));
            header("Location: comentarios3.php");
        }
    }

    $comentarios = $acme->query('SELECT usuario, comentario
        FROM comentarios
        ORDER BY id DESC
        LIMIT 10');

?><!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8" />
  <title>Comentarios 3</title>
</head>
<body>
  <h1>Comentarios 3</h1>

  <?php
    if ($malhablado) {
        echo "<h2>El comentario ha sido descartado</h2>";
        echo "<p>Porque eres un malhablado</p>";
    }
  ?>

  <h2>Añadir un comentario</h2>
  <form action="comentarios3.php" method="POST">
    <p>Usuario: <input type="text" name="user" /></p>
    <p>Comentario: <textarea name="comment"></textarea></p>
    <p><input type="submit" value="Enviar" /></p>
  </form>

  <h2>Todos los comentarios</h2>
  <?php
    foreach ($comentarios as $fila) {
        echo "<h3>$fila[usuario]</h3>";
        echo "<p>$fila[comentario]</p>";
    }
  ?>

</body>
</html>
