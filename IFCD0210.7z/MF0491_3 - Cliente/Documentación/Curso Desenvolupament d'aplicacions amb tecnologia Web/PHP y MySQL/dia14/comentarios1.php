<?php
/*
    http://localhost/dia14/comentarios1.php
*/

require_once "../conexion.php";
$acme = new PDO("mysql:host=$servidor;dbname=$basedatos", $usuario, $clave);
$acme->exec("SET CHARACTER SET utf8");

$acme->exec("CREATE TABLE comentarios(
    id INT AUTO_INCREMENT,
    usuario VARCHAR(16),
    comentario TEXT,
    PRIMARY KEY (id)
)");

/*
  $acme->exec("INSERT INTO comentarios(usuario,comentario)
    VALUES ('pepe','Bla bla bla...')");

  Para evitar los ataques de inserción de código SQL maligno
  hay que utilizar el prepare y el execute.
*/
$plantilla = $acme->prepare("INSERT INTO comentarios(usuario,comentario)
  VALUES (?, ?)");
$ok = $plantilla->execute(array('pepe','Bla bla bla...'));
$ok = $plantilla->execute(array('ana','Cosas...'));
$ok = $plantilla->execute(array('maria','Más cosas...'));

if ($ok) {
    echo "<p>El comentario ha sido insertado</p>";
}
else {
    echo "<p>ERROR: No he insertado el comentario</p>";
}


/*
    Mostrar todos los comentarios de un sólo usuario
*/
$plantilla2 = $acme->prepare("SELECT comentario FROM comentarios WHERE usuario = ?");
$ok2 = $plantilla2->execute(array('pepe'));
if ($ok2) {
    $datos = $plantilla2->fetchAll();
    foreach($datos as $fila) {
        echo "<p>".$fila['comentario']."</p>";
    }
}
else {
    echo "<p>Sin comentarios</p>";
}






