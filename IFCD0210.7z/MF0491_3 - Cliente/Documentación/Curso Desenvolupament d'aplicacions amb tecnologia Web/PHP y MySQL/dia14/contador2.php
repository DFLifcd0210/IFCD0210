<?php
  // http://localhost/dia14/contador2.php  

?><!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8" />
  <title>Contador 2</title>
  <style>
    #contador {
        background-color:#333;
        color:#ccc;
        padding:0.2em 0.5em;
        font-family:courier new,monospace;
        font-weight:bold;
        text-shadow:1px 1px 0 #000;
    }
  </style>
</head>  
<body>
    <h1>Contador 2</h1>
    <p><?php echo ucfirst(str_repeat('bla rebla requete bla, ',100)); ?>&hellip;</p>
    
    <p>Contador de visitas: 
        <span id="contador"><?php include 'contador.php' ?></span>
    </p>
</body>
</html>    