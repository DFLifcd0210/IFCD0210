<?php
	/*
		http://localhost/dia02/if3.php
			
			if () {				
			}
			elseif () {
			}
			elseif () {
			}
			else {		
			}
	*/
	
	$numero = 30;
	
	echo "inicio<br>";
	
	if ($numero > 100) {
		echo "$numero es mayor que 100<br>";
	}
	elseif ($numero > 50) {
		echo "$numero es mayor que 50 y menor o igual a 100<br>";
	}
	elseif ($numero > 10) {
		echo "$numero es mayor que 10 y menor o igual a 50<br>";
	}
	else {
		echo "$numero es menor o igual que 10<br>";
	}
	
	echo "fin<br>";


?>