<?php 
/*
	http://localhost/dia02/semana.php
*/
	$dia = 3;
	
	if ($dia == 1) {
		echo "Lunes";
	}
	elseif ($dia == 2) {
		echo "Martes";
	}
	elseif ($dia == 3) {
		echo "Miércoles";
	}
	elseif ($dia == 4) {
		echo "Jueves";
	}
	elseif ($dia == 5) {
		echo "Viernes";
	}
	elseif ($dia == 6) {
		echo "Sábado";
	}
	elseif ($dia == 7) {
		echo "Domingo";
	}
	else {
		echo "Error";
	}
	
	/*
	if ($dia == 1) {
		echo "Lunes";
	}
	else {
		if ($dia == 2) {
			echo "Martes";		
		}
		else {
			if ($dia == 3) {
				echo "Miércoles";
			}
			....
		}
	}
	*/
	
	
	

?>