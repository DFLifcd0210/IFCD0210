<?php
	/*
		http://localhost/dia02/if2.php
			
			if () {				
			}
			else {				
			
			}
	*/
	
	$numero = 50;
	
	echo "inicio<br>";
	
	if ($numero > 100) {
		echo "$numero es mayor que 100<br>";
	}
	else {
		echo "$numero es menor o igual que 100<br>";
	}
	
	echo "fin<br>";


?>