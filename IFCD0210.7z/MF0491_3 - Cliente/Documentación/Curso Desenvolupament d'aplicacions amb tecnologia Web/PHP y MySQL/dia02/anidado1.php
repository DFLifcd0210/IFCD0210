<?php
/*
	http://localhost/dia02/anidado1.php

*/

	$paraguas = true; // Booleano: true, false
	$llueve = true; 
	
	if ($llueve) {
		if ($paraguas) {		
			echo "Usa el paraguas para no mojarte";
		}
		else {
			echo "Te vas a mojar";
		}
	}
	else {
		if ($paraguas) {			
			echo "No necesitas el paraguas";
		}
		else {
			echo "Hace buen día";
		}
	}