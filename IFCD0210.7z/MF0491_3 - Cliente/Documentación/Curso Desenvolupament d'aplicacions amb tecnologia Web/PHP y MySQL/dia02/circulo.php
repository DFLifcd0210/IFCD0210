<?php 
	/*
		http://localhost/dia02/circulo.php
		
		Y conjuntivo:
		   &&
		   and
		   
		O:
		   ||
		   or
	*/

	//$grados = -60;
	$grados = 230; 
	//$grados = 400;
	
	if ($grados >= 0 and $grados < 360) {
		echo $grados."º es correcto<br>";
	}
	else {
		echo $grados."º no está entre 0º y 360º<br>";
	}
	
	
	if ($grados == 0 || 
	    $grados == 90 || 
		$grados == 180 || 
		$grados == 270
	){
		echo $grados."º es múltiplo de 90º<br>";
	}
	else {
		echo "No es múltiplo de 90º<br>";
	}
	
	
	
	

?>