<?php
	// Leer el parámetro GET que se llama tipo
	// y guardarlo en una variable
	
	$deporte = $_GET['tipo'];	
	
?><!DOCTYPE html>
<html>
<head>
<meta charset="utf-8" />
<title><?php echo $deporte; ?></title>
</head>
<body>
<h1><?php echo $deporte; ?></h1>
<img src="fotos/<?php echo $deporte; ?>.jpg" />
</body>
</html>






