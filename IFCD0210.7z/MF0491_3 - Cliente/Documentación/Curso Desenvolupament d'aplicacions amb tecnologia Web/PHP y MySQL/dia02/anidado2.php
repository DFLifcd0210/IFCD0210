<?php
/*
	http://localhost/dia02/anidado2.php
*/
	$paraguas = true; // Booleano: true, false
	$llueve = true; 
	
	if ($llueve) {
		echo "Está lloviendo<br>";		
		if ($paraguas) {		
			echo "Usa el paraguas para no mojarte<br>";
		}
		else {
			echo "Te vas a mojar<br>";
		}
	}
	else {
		echo "No llueve<br>";
		if ($paraguas) {			
			echo "No necesitas el paraguas<br>";
		}
		else {
			echo "Hace buen día<br>";
		}
	}