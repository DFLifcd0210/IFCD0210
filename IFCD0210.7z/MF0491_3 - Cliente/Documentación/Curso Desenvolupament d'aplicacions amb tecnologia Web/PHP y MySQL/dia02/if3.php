<?php
	/*
		http://localhost/dia02/if3.php
			
			if () {				
			}
			elseif () {
			}
			else {		
			}
	*/
	
	$numero = 30;
	
	echo "inicio<br>";
	
	if ($numero > 100) {
		echo "$numero es mayor que 100<br>";
	}
	elseif ($numero > 50) {
		echo "$numero es mayor que 50 y menor o igual a 100<br>";
	}
	else {
		echo "$numero es menor o igual que 50<br>";
	}
	
	echo "fin<br>";


?>