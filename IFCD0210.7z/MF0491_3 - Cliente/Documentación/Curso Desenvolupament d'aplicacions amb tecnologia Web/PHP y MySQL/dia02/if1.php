<?php
	/*
		http://localhost/dia02/if1.php
			
			if () {
				
			}
	*/
	
	$numero = 500;
	
	echo "inicio<br>";
	
	if ($numero > 100) {
		echo "$numero es mayor que 100<br>";
	}
	
	echo "fin<br>";


?>