<?php 
	/*
		http://localhost/dia02/edad.php
	*/
	
	$edad = 33;
	
	if ($edad >= 0 && $edad < 18) {		
		echo "Joven";
	}
	else if ($edad >= 18 && $edad < 65) {
		echo "Trabajador";
	}
	else if ($edad >= 65 && $edad < 150) {		
		echo "Jubilado";
	}
	else {
		echo "ERROR";
	}
	
?>	