<?php
	/*
		Variables, asignación y 
		mostrar valor
	*/
	
	$importe = 5000;
	$porcIva = 0.21;
	
	$iva = $importe * $porcIva;
	$total = $importe + $iva;
	
	echo $total;
	
	/*
		Este programa se ha de ejecutar con el Apache
			http://localhost/dia02/repaso1.php
	*/
?>
