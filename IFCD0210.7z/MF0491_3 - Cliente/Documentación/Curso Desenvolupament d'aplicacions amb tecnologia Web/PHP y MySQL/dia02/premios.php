<?php

  //  http://localhost/dia02/premios.php
  
  $persona = "Pepe";
  $posicion = 10;
  
  if ($posicion == 1) {
	echo "$persona es el campeón";  
  }
  elseif ($posicion == 2) {
	echo "$persona es el subcampeón";
  }
  elseif ($posicion == 3) {
	echo "$persona es medalla de bronce";
  } 
  else {
	echo "Lo importante es participar";  
  }
  