<?php

	$pulgadas = 40;
	$centimetros = $pulgadas * 2.54;
	
	echo "Un TV de $pulgadas pulgadas son $centimetros centímetros";

	// http://localhost/dia02/pulgadas.php
	
	// http://php.net/manual/es/
?>