<?php
	// http://localhost/dia02/centigrados.php

	$centigrados = 10;
	$fahrenheit = $centigrados*9/5 + 32;
	
?><!DOCTYPE html>
<html>
<head>
<meta charset="utf-8" />
<title>De Celsius a Fahrenheit</title>
</head>
<body>
<h1>De Celsius a Fahrenheit</h1>
<p><?php echo $centigrados; ?> grados centígrados son <?php echo $fahrenheit; ?> grados Fahrenheit</p>
</body>
</html>