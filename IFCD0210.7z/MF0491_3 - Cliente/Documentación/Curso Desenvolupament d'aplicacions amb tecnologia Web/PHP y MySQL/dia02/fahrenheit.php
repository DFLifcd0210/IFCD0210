<?php
	// http://localhost/dia02/fahrenheit.php

	$fahrenheit = 50;
	$centigrados = ($fahrenheit - 32)*5/9;
	
?><!DOCTYPE html>
<html>
<head>
<meta charset="utf-8" />
<title>De Fahrenheit a Celsius</title>
</head>
<body>
<h1>De Fahrenheit a Celsius</h1>
<p><?php echo $fahrenheit; ?> grados Fahrenheit son <?php echo $centigrados; ?> grados centígrados</p>
</body>
</html>