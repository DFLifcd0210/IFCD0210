-- Lenguaje SQL
-- https://dev.mysql.com

-- 0) Borrar la base de datos

DROP DATABASE bdacme;

-- 1) Crear una base datos

CREATE DATABASE bdacme
  DEFAULT CHARACTER SET utf8
  DEFAULT COLLATE utf8_general_ci;
  
-- 2) Indicar la BD predeterminada

USE bdacme;

-- 3) Crear la tabla usuarios

CREATE TABLE users(
    id INT AUTO_INCREMENT,
    user VARCHAR(16) NOT NULL,
    password VARCHAR(32),
    email VARCHAR(32),
    --
    PRIMARY KEY (id),
    UNIQUE KEY user (user)
);

-- 4) Insertar datos en la tabla
INSERT INTO users(id, user, password, email) VALUES     (NULL, 'pepe', '123', 'pepe@gmail.com'),
     (NULL, 'ana', '456', 'ana@outlook.com'),
     (NULL, 'pablo', '789', NULL),
     (NULL, 'maria', '123', NULL);

-- 5) Modificar datos de la tabla
UPDATE users SET 
    user = UPPER(user),
    password = MD5(password)
WHERE id IN (1,2,4);

-- 6) Borrar datos
DELETE FROM users WHERE id = 3;

-- 7) Consulta en la tabla
SELECT user, email
FROM users
WHERE email IS NOT NULL
ORDER BY user DESC;

SELECT *
FROM users
WHERE user LIKE 'p%'
ORDER BY id;

-- 8) Comprobar error por PRIMARY KEY
INSERT INTO users(id, user) VALUES (1, 'manolito'); -- Da error
INSERT INTO users(id, user) VALUES (NULL, 'manolito'); -- OK

-- Comprobar error por UNIQUE KEY
INSERT INTO users(id, user) VALUES (NULL, 'pepe'); -- Da error
INSERT IGNORE INTO users(id, user) VALUES (NULL, 'pepe');


-- ==============================================
-- tabla products

CREATE TABLE products (
    id INT AUTO_INCREMENT,
    product VARCHAR(16) NOT NULL,
    price DECIMAL(8,2) DEFAULT 0,
    special BOOLEAN DEFAULT FALSE,
    category ENUM('normal','extra','suprema'),
    notes TEXT,
    --
    PRIMARY KEY (id),
    UNIQUE KEY product (product)
);

INSERT INTO products(id,product,price,special,category,notes)
VALUES
  (1, 'Pantalla', 45.50, FALSE, 'normal', NULL),
  (2, 'Teclado', 12.75, FALSE, 'normal', NULL),
  (3, 'Ratón', 5.34, TRUE, 'extra', NULL);
  
SELECT * 
FROM products;  
  











  