<?php
/*
    http://localhost/dia09/clases2.php
    
    1) Crear una clase llamada Vehiculo
       Variables:
         - nombre del vehículo
         - número de ruedas
         - combustible utilizado
       Funciones:
         - Mostrar
           "El vehículo X tiene N ruedas"
         - Gastar
           "El vehículo X gasta Y"
     2) A partir de la clase anterior crea los 
        siguientes objetos:
         - Un coche de 4 ruedas y gasolina
         - Un camión de 8 ruedas y gasoil
         - Una bicicleta de 2 ruedas y batería
     3) Usa la función mostrar del coche  
        Usa la función gastar del camión
*/

class Vehiculo {
    
    public $nombre;
    public $ruedas;
    public $combustible;
    
    public function mostrar() {
        echo "El vehículo ".$this->nombre.
          " tiene ".$this->ruedas." ruedas<br>";
    }
    public function gastar() {
        echo "El vehículo ".$this->nombre.
          " gasta ".$this->combustible."<br>";
    }
    
} // end class Vehiculo

$uno = new Vehiculo();
$dos = new Vehiculo();
$tres = new Vehiculo();

$uno->nombre = "coche";
$uno->ruedas = 4;
$uno->combustible = "gasolina";

$dos->nombre = "camión";
$dos->ruedas = 8;
$dos->combustible = "gasoil";

$tres->nombre = "bicicleta";
$tres->ruedas = 2;
$tres->combustible = "bateria";

$uno->mostrar();
$dos->gastar();


