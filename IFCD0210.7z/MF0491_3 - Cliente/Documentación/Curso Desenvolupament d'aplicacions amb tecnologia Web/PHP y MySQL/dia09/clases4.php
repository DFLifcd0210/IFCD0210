<?php
/*  http://localhost/dia09/clases4.php
    
    1) Crea la clase Rectangulo con las siguientes variables privadas:
        - Coordenada X e Y
        - Ancho y alto
        - Color
    2) Crea el constructor de la clase para inicializar todas
       las variables de la clase
    3) Crea una función en la clase que imprima el mensaje:
         "El rectángulo está en la posición X,Y
          tiene un tamaño de ANCHOxALTO píxeles
          y es de color COLOR"              
    4) Crea tres objetos rectángulo con las siguientes propiedades:
          100,200  300x400  red
          200,300  100x100  green
          200,50   50x100   blue          
    5) Usa la función imprimir con los 3 objetos.
    6) Haz una función dibujar dentro de la clase que 
       pinte el rectángulo. Usa la etiqueta DIV con su atributo style. 
         <div style="position:absolute; left:100px; top:200px; width:300px; height:400px; background-color:red">Rectángulo</div>
    7) Llama a la función dibujar para cada uno de los 3 rectángulos.
*/

    class Rectangulo {
        
        private $left;
        private $top;
        private $width;
        private $height;
        private $bgcolor;
        
        public function __construct($x, $y, $ancho, $alto, $color) {
            $this->left = $x;
            $this->top = $y;
            $this->width = $ancho;
            $this->height = $alto;
            $this->bgcolor = $color;
        }
        
        public function imprimir() {
            echo "El rectángulo está en la posición {$this->left},{$this->top}
          tiene un tamaño de {$this->width}&times;{$this->height} píxeles
          y es de color {$this->bgcolor}<br />";
        }
        
        public function dibujar() {
            echo "<div style=\"position:absolute; left:{$this->left}px; top:{$this->top}px; width:{$this->width}px; height:{$this->height}px; background-color:{$this->bgcolor}\">Rectángulo</div>";
        }        
        
    } // End Rectangulo
    
    $r1 = new Rectangulo(100,200, 300,400, 'red');
    $r2 = new Rectangulo(200,300, 100,100, 'green');
    $r3 = new Rectangulo(200,50, 50,100, 'blue'); 
        
?><!DOCTYPE html>
<html>    
<head>
  <title>Rectángulos</title>
  <meta charset="utf8" />
</head>
<body>
    <h1>Rectángulos</h1>
    <?php 
        $r1->imprimir();
        $r2->imprimir();
        $r3->imprimir();
        
        $r1->dibujar();
        $r2->dibujar();
        $r3->dibujar();
    ?>
</body>
</html>  
    
    
    
    
    
    
    
    