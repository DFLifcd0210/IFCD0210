<?php
/*
    OOP = Programación orientada a objetos
    Clases y objetos en PHP
    http://php.net/manual/es/language.oop5.basic.php
    
    Una clase es un grupo de funciones y variables que están relacionados entre sí.
*/
  
  class Persona {      
      public $nombre;
      public $nif;
      public $sexo;
      
      function saludar() {     
          echo "Hola ".$this->nombre.'<br>';
          //echo "Hola {$this->nombre}";
      }
      function despedirse() {
          echo "Adiós ".$this->nombre.'<br>';
      }
  } // class Persona
  
  /*
    Crear objetos a partir de la clase
    Instanciar objetos
  */
  $yo = new Persona();
  $tu = new Persona();
  $el = new Persona();
  
  $yo->nombre = 'Pepe';
  $yo->nif = '123A';
  $yo->sexo = 'M';
  
  $tu->nombre = 'Ana';
  $tu->nif = '456B';
  $tu->sexo = 'F';
  
  $el->nombre = 'Marco';
  $el->nif = '789C';
  $el->sexo = 'M';
  
  $yo->saludar();  
  $el->despedirse();
  
  
  
  
  