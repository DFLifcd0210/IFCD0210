<?php
/*
    http://localhost/dia09/clases3.php
    
    Poner las variables en privado para que se puedan
    usar desde fuera de la clase.
    
    Crear el constructor de la clase.
*/

class Vehiculo {
    
    private $nombre; // $this->nombre
    private $ruedas;
    private $combustible;
    
    public function __construct($nombre, $ruedas, $combustible) {
        $this->nombre = $nombre;
        $this->ruedas = $ruedas;
        $this->combustible = $combustible;
    }
    
    public function mostrar() {
        echo "El vehículo ".$this->nombre.
          " tiene ".$this->ruedas." ruedas<br>";
    }
    public function gastar() {
        echo "El vehículo ".$this->nombre.
          " gasta ".$this->combustible."<br>";
    }
    
} // end class Vehiculo

$uno = new Vehiculo('coche', 4, 'gasolina');
$dos = new Vehiculo('camión', 8, 'gasoil');
$tres = new Vehiculo('bicicleta', 2, 'batería');

$uno->mostrar();
$dos->gastar();


