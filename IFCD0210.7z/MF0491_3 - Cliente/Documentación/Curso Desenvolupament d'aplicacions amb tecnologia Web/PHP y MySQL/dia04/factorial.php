<?php
/*
  http://localhost/dia04/factorial.php
  
  Factorial de 10
  Multiplicar los 10 primeros números
*/
  /*
  // Versión 1.0
  $contador = 1;
  $acumulador = 1;  
  while ($contador <= 10) {
      $acumulador = $acumulador * $contador;
      $contador = $contador + 1;   
  }
  echo "El factorial de 10 es $acumulador";
  */
    
  // Versión 2.0
  $contador = 1;
  $acumulador = 1;  
  while ($contador <= 10) {
      $acumulador *= $contador;
      $contador++;   
  }
  echo "El factorial de 10 es $acumulador";
    
    
    
    