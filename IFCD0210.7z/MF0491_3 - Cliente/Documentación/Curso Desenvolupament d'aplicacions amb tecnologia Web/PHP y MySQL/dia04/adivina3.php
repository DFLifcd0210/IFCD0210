<?php
/*
  http://localhost/dia04/adivina3.php
  
  Lista HTML de enlaces: <ul>, <li>, <a>
*/
    $enlaces = array(
        "http://php.net",
        "http://www.google.com",
        "https://atom.io",
        "http://xampp.org",
        "http://mysql.com",
        "http://notepad-plus-plus.org",
    );
    
    echo "<ul>\n";
    foreach ($enlaces as $link) {
        echo "<li><a href=\"$link\">$link</a></li>\n";
    }
    echo "</ul>\n";
    
    
    
    
    
    
    
    
    
    