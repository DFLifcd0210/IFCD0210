<?php
/*
  http://localhost/dia04/cinco.php
  
  Imprimir:  0 5 10 15 ... 100
*/
    
    for ($secuencia=0; $secuencia<=100; $secuencia += 5) {
        echo "$secuencia ";
    }
    
    echo "<br>";
    
    $secuencia = 0;
    while ($secuencia <= 100) {
        echo "$secuencia ";
        $secuencia += 5;
    }