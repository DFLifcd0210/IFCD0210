<?php
/*
  http://localhost/dia04/adivina2.php
*/
    $enlaces = array(
        "http://php.net",
        "http://www.google.com",
        "https://atom.io",
        "http://xampp.org",
        "http://mysql.com",
        "http://notepad-plus-plus.org",
    );
    
    foreach ($enlaces as $link) {
        echo "<a href=\"$link\">$link</a><br>";
    }
    
    
    
    
    
    
    
    
    
    