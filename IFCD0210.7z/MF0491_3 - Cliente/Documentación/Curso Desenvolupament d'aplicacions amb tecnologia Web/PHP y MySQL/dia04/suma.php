<?php
/*
  http://localhost/dia04/suma.php
  
  Suma de los 100 primeros números
  1+2+3+...+100  
*/
    /*
    // Versión 1.0
    for ($contador=1; $contador<=100; $contador++) {
        echo "$contador<br>";
    }
    */
    
    /*
    // Versión 1.5
    $contador = 1;
    $acumulador = 0;
    $acumulador = $acumulador + $contador;
    $contador++;
    $acumulador = $acumulador + $contador;
    $contador++;
    $acumulador = $acumulador + $contador;
    $contador++;
    $acumulador = $acumulador + $contador;
    $contador++;
    // etc.
    */
    
    /*
    // Versión 2.0
    $acumulador = 0;
    for ($contador=1; $contador<=100; $contador++) {
        $acumulador = $acumulador + $contador; 
        echo "contador: $contador, acumulador: $acumulador<br>";
    }        
    // 1 = 0 + 1
    // 3 = 1 + 2
    // 6 = 3 + 3
    // 10 = 6 + 4
    // 15 = 10 + 5
    */
    
    // Versión 3.0
    $acumulador = 0;
    for ($contador=1; $contador<=100; $contador++) {
        $acumulador = $acumulador + $contador;         
    }       
    echo "El resultado es: $acumulador";
    
    
    
    
    
    
    