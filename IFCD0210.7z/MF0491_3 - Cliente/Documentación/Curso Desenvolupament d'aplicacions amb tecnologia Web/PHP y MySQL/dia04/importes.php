<?php
/*
    http://localhost/dia04/importes.php
*/

    // Crea un array vacío
    $importes = array();
    
    // Imprime 0 elementos
    echo "El array tiene ".count($importes)." elementos<br>";
    
    // Añade mil números aleatorios al array
    for ($i=0; $i<1000; $i++) {      
        // Añade un nuevo elemento array (apilar)
        $importes[] = rand(0,10000);        
    }
    
    // Imprime que el array tiene 1000 elementos
    echo "El array tiene ".count($importes)." elementos<hr>";
    
    // 1) Muestra todos los elementos del array separados por espacio
    echo "Los números aleatorios del array son:<br>";
    foreach ($importes as $numero) {
        echo "$numero ";
    }
    echo "<hr>";
    
    // 2) Muestra el total de importes del array
    echo "La suma de todos los números aleatorios da:<br>";
    $total = 0;
    foreach ($importes as $numero) {
        $total = $total + $numero;
    }
    echo "$total<hr>";
    
    // 3) Ordena los elementos del array de menor a mayor
    //    Busca la solución en Google
    sort($importes);
    
    // 4) Imprime los elementos ordenados
    foreach ($importes as $numero) {
        echo "$numero ";
    }
    
    
    
    
    