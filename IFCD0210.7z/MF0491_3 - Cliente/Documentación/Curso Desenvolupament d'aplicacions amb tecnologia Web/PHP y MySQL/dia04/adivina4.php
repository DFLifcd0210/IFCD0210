<?php
/*
  http://localhost/dia04/adivina4.php
  
  Array asociativo
*/
    $enlaces = array(
      // clave=> valor /////
        'PHP'=> "http://php.net",
        'Google'=> "http://www.google.com",
        'Atom'=> "https://atom.io",
        'XAMPP'=> "http://xampp.org",
        'MySQL'=> "http://mysql.com",
        'Notepad++'=> "http://notepad-plus-plus.org",
    );
    
    /*
    foreach ($enlaces as $link) {
        echo "$link<br>";
    }
    */
    /*
    echo $enlaces['Atom'];
    */
    /*
    foreach ($enlaces as $clave=>$link) {
        echo "El enlace de $clave es $link<br>";
    }
    */
       
    echo "<ol>";
    foreach ($enlaces as $clave=>$link) {
        echo "<li><a href=\"$link\" target=\"_blank\">$clave</a></li>";
    }
    echo "</ol>";
    
    
    
    
    
    
      
    
    
    
    
    
    
    
    