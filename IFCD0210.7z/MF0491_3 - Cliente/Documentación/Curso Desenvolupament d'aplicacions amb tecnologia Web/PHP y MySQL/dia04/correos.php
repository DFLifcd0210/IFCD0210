<?php
/*
    http://localhost/dia04/correos.php
*/
   $alumnos = array(
        "Alcides"=> "Está trabajando",
        "Alex"=> "alexftnweb@gmail.com",
        "Angel"=> "angelftnweb@gmail.com",
        "Bryan"=> "bryan-aym@hotmail.com",
        "Paola"=> "paolaftnweb@gmail.com",
        "David"=> "davidftnweb@gmail.com",
        "Francesc" => "francescftnweb@gmail.com",
        "Francisco" => "fco.cascales@gmail.com",
        "Josep Maria"=> "No se lo sabe",
        "Julio"=> "juliodgftnweb@gmail.com",
        "Katiuzka"=> "katyftnweb@gmail.com",
        "Laura"=> "Se ha ido",
        "Miguel"=> "miguelftnweb@gmail.com",
        "Rebeca"=> "No se supo más",   
   ); 
   
   if (isset($_GET['nombre'])) {
       $clave = $_GET['nombre'];
       $correo = $alumnos[$clave];
       echo "<h1>$clave</h1>";
       echo "<p>$correo</p>";
       echo "<p><a href=\"correos.php\">Listado</a></p>";
   }
   else {
       echo "<h1>Alumnos</h1>";
       echo "<ul>";
       foreach ($alumnos as $clave=>$correo) {
          $enlace = "correos.php?nombre=$clave";      
          echo "<li><a href=\"$enlace\">$clave</a></li>";
       }
       echo "</ul>";
   }  

?>   