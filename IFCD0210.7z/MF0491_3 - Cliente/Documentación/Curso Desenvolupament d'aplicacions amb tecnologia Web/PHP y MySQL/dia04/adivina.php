<?php
/*
  http://localhost/dia04/adivina.php
*/
    $enlaces = array(
        "http://php.net",
        "http://www.google.com",
        "https://atom.io",
        "http://xampp.org",
        "http://mysql.com",
        "http://notepad-plus-plus.org",
    );
    
    //$aleatorio = rand(0,5);
    $aleatorio = rand(0, count($enlaces)-1);
    
    $link = $enlaces[$aleatorio];
    
    echo "<a href=\"$link\">$link</a>";
    
    
    
    
    
    
    
    
    
    