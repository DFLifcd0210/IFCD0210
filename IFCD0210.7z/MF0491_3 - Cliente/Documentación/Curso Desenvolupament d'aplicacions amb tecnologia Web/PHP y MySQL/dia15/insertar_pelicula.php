<?php
    // http://localhost/dia15/insertar_pelicula.php

    /*
        // Array vacío: no se envió el formulario
        $_POST = array()

        // Array no vacío: el formulario fue enviado si rellenar los campos
        $_POST = array(
            'titulo'=>"",
            'año'=>"",
            'protagonista'=>"")

        // Array no vacío: el formulario fue enviado con valor en los campos
        $_POST = array(
            'titulo'=>"PRUEBA",
            'año'=>"1934",
            'protagonista'=>"Pedro")
   */

   if (empty($_POST)) {
        $mensaje = "";
   }
   elseif (empty($_POST['titulo'])) {
        $mensaje = "Falta el título de la película";
   }
   else {
        require_once "../conexion.php";
        $acme = new PDO("mysql:host=$servidor;dbname=$basedatos", $usuario, $clave);
        $acme->exec("SET CHARACTER SET utf8");

        $plantilla = $acme->prepare("INSERT INTO peliculas(titulo,año,protagonista) VALUES (?,?,?)");
        $ok = $plantilla->execute(array($_POST['titulo'],$_POST['año'],$_POST['protagonista']));
        if ($ok) {
            $id = $acme->lastInsertId();
            if ($id) {
                $mensaje = "He insertado la película con id=$id";
            }
            else {
                $mensaje = "No he insertado nada";
            }
       }
       else {
           $mensaje = "No he podido insertar la película: puede que esté repetida";
       }
   }

?><!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8" />
  <title>Insertar una nueva película</title>
</head>
<body>
    <h1>Insertar una nueva película</h1>
    <?php
        if (!empty($mensaje)) {
            echo "<p>$mensaje</p>";
        }
    ?>
    <form action="insertar_pelicula.php" method="POST">
        <p>
            <label for="titulo">Título</label>
            <input type="text" name="titulo" id="titulo" maxlength="32" />
        </p>
        <p>
            <label for="año">Año</label>
            <input type="text" name="año" id="año" maxlength="4" />
        </p>
        <p>
            <label for="protagonista">Protagonista</label>
            <input type="text" name="protagonista" maxlength="32">
        </p>
            <input type="submit" value="Insertar" />
        <p>
    </form>
</body>
</html>
