<?php
    // http://localhost/dia15/buscar_pelicula.php

    $datos = array();
    $buscador = '';

    if (empty($_GET)) {
        $mensaje = "";
    }
    elseif (empty($_GET['buscador'])) {
        $mensaje = "Falta introducir el texto a buscar";
    }
    else {
        require_once "../conexion.php";
        $acme = new PDO("mysql:host=$servidor;dbname=$basedatos", $usuario, $clave);
        $acme->exec("SET CHARACTER SET utf8");

        $plantilla = $acme->prepare("SELECT * FROM peliculas WHERE titulo LIKE ? OR protagonista LIKE ? LIMIT 100");
        $buscador = $_GET['buscador'];
        $mascara = "%$buscador%";
        $ok = $plantilla->execute(array($mascara, $mascara));
        if ($ok) {
            $datos = $plantilla->fetchAll();
            $mensaje = "He encontrado ".count($datos)." coincidencia(s)";
        }
        else {
            $mensaje = "Hay algún problema al buscar";
        }
    }

?><!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8" />
  <title>Buscar película</title>
</head>
<body>
    <h1>Buscar película</h1>
    <form action="buscar_pelicula.php" method="GET">
        <p>
            <input type="text" name="buscador"
                value="<?php echo $buscador; ?>"
                placeholder="Título o protagonista" />
            <input type="submit" value="Buscar" />
        </p>
    </form>

    <?php
        echo "<h2>$mensaje</h2>";
        if (!empty($datos)) {
            echo '<table border="1">';
            echo '<tr>';
            echo '<th>Título</th><th>Año</th><th>Protagonista</th>';
            echo '</tr>';
            foreach($datos as $peli) {
                echo "<tr>";
                echo "<td><strong>$peli[titulo]</strong></td>";
                echo "<td>$peli[año]</td>";
                echo "<td>$peli[protagonista]</td>";
                echo "</tr>";
            }
            echo '</table>';
        }
     ?>

</body>
</html>
