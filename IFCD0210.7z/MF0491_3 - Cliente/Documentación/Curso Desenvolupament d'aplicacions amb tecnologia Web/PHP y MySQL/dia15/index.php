<?php
    require_once('../template.php');
?><!DOCTYPE html>
<html>
<head>
<meta charset="utf-8" />
<title>PHP 15</title>
</head>
<body>
<h1>PHP 15</h1>
<h2>Tabla películas: Insertar/Listar/Buscar</h2>
<ul>
    <li><?php enlazar('peliculas_ejercicio.txt', 'Enunciado del ejercicio'); ?></li>
    <li><?php enlazar('insertar_pelicula.php', 'Insertar una nueva película'); ?></li>
    <li><?php enlazar('listar_peliculas.php', 'Listado de películas'); ?></li>
    <li><?php enlazar('buscar_pelicula.php', 'Buscar una película por título o protagonista'); ?></li>
    <li><?php enlazar('buscar_anos.php', 'Buscar una película entre años'); ?></li>
</ul>

</body>
</html>
