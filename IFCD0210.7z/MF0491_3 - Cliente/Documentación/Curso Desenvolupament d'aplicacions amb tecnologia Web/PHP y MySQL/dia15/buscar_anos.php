<?php
    // http://localhost/dia15/buscar_anos.php

    $datos = array();
    $inicio = '';
    $final = '';

    if (empty($_GET)) {
        $mensaje = "";
    }
    elseif (empty($_GET['inicio']) || empty($_GET['final'])) {
        $mensaje = "Falta introducir el año de inicio o el año final";
    }
    else {
        require_once "../conexion.php";
        $acme = new PDO("mysql:host=$servidor;dbname=$basedatos", $usuario, $clave);
        $acme->exec("SET CHARACTER SET utf8");

        $plantilla = $acme->prepare("SELECT * FROM peliculas WHERE año BETWEEN ? AND ? LIMIT 100");
        $inicio = $_GET['inicio'];
        $final = $_GET['final'];
        $ok = $plantilla->execute(array($inicio, $final));
        if ($ok) {
            $datos = $plantilla->fetchAll();
            $mensaje = "He encontrado ".count($datos)." coincidencia(s)";
        }
        else {
            $mensaje = "Hay algún problema al buscar";
        }
    }

?><!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8" />
  <title>Buscar por años</title>
</head>
<body>
    <h1>Buscar por años</h1>
    <form action="buscar_anos.php" method="GET">
        <p>
            <input type="text" name="inicio"
                value="<?php echo $inicio; ?>"
                placeholder="año de inicio" />
            <input type="text" name="final"
                value="<?php echo $final; ?>"
                placeholder="año final" />
            <input type="submit" value="Buscar" />
        </p>
    </form>

    <?php
        echo "<h2>$mensaje</h2>";
        if (!empty($datos)) {
            echo '<table border="1">';
            echo '<tr>';
            echo '<th>Título</th><th>Año</th><th>Protagonista</th>';
            echo '</tr>';
            foreach($datos as $peli) {
                echo "<tr>";
                echo "<td><strong>$peli[titulo]</strong></td>";
                echo "<td>$peli[año]</td>";
                echo "<td>$peli[protagonista]</td>";
                echo "</tr>";
            }
            echo '</table>';
        }
     ?>

</body>
</html>
