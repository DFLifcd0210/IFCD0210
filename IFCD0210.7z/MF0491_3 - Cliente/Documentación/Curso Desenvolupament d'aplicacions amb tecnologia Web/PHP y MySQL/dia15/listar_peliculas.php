<?php
    // http://localhost/dia15/listar_peliculas.php

    require_once "../conexion.php";
    $acme = new PDO("mysql:host=$servidor;dbname=$basedatos", $usuario, $clave);
    $acme->exec("SET CHARACTER SET utf8");

    $datos = $acme->query("SELECT * FROM peliculas ORDER BY titulo");

?><!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8" />
  <title>Listado de películas</title>
</head>
<body>
    <h1>Listado de películas</h1>
    <?php
        echo "<ol>";
        foreach($datos as $peli) {
            echo "<li>";
            echo " <h2>$peli[titulo]</h2>";
            echo " <p>Año: <strong>$peli[año]</strong></p>";
            echo " <p>Protagonista: <strong>$peli[protagonista]</strong></p>";
            echo "</li>";
        }
        echo "</ol>";
    ?>
</body>
</html>
