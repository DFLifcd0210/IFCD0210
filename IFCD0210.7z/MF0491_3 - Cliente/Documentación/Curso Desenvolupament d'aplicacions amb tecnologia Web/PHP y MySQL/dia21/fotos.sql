CREATE TABLE fotos(
  id INT AUTO_INCREMENT,
  foto VARCHAR(64) NOT NULL,
  autor VARCHAR(64),
  fecha DATE,
  descripcion TEXT,
  PRIMARY KEY (id),
  UNIQUE KEY (foto)
);