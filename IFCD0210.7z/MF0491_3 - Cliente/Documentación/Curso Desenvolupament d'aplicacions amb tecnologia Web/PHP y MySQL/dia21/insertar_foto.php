<?php
/*
  http://localhost/php/dia21/insertar_foto.php
*/

  $mensaje = '';
  $error = false;
  $fecha = date('Y-m-d'); // Fecha de hoy: 2015-04-23
  $destino = '';

  //echo "hola $fecha"; -- hola 2015-04-23
  //echo 'hola $fecha'; -- hola $fecha

  if (!empty($_FILES)) { // Se ha subido algún archivo

    if ($_FILES['foto']['error'] == 0) { // No hay error

      // Diferente de JPG y diferente de PNG y diferente de GIF
      if ($_FILES['foto']['type'] != 'image/jpeg' &&
          $_FILES['foto']['type'] != 'image/png' &&
          $_FILES['foto']['type'] != 'image/gif') {
        $mensaje .= "Sólo se admiten fotos JPG, GIF o PNG<br>";
        $error = true;
      }
      if ($_FILES['foto']['size'] > 2000000) {
        $mensaje .= "La foto es demasiado grande, tiene más de 2 MB<br>";
        $error = true;
      }

      if ($mensaje == '') {
        $destino = "fotos/" . $_FILES['foto']['name'];

        $ok = move_uploaded_file(
          $_FILES['foto']['tmp_name'],
          $destino
        );

        if ($ok) {
          $mensaje .= "La foto ha sido guardada correctamente<br>";
        }
        else {
          $mensaje .= "La foto no se ha podido mover<br>";
          $error = true;
        }
      }
    }
    else {
      $mensaje .= "Error al subir el archivo<br>";
      $error = true;
    }
  }

  /*
    empty($error)
    !$error
    $error == false
  */
  if (!empty($_POST) && !$error) {  // No vacío POST y no error

    // Recuperar los datos introducidos por el usuario
    $foto = $_FILES['foto']['name'];
    $autor = trim($_POST['autor']);
    $fecha = trim($_POST['fecha']);
    $descripcion = trim($_POST['descripcion']);

    // Comprobar que los datos sean correctos
    if (empty($autor))      { $mensaje .= 'Falta el autor<br>'; $error = true; }
    if (empty($fecha))      { $mensaje .= 'Falta la fecha<br>'; $error = true; }
    if (empty($descripcion)){ $mensaje .= 'Falta la descripción<br>'; $error = true; }

    // Si no hay mensaje de error insertamos el artículo en la BD
    if (!$error) {
      require_once "../conexion.php";
      $acme = new PDO("mysql:host=$servidor;dbname=$basedatos", $usuario, $clave);
      $acme->exec("SET CHARACTER SET utf8");

      $plantilla = $acme->prepare("INSERT INTO fotos(foto, autor, fecha, descripcion) VALUES (?,?,?,?)");
      if ($plantilla->execute(array($foto, $autor, $fecha, $descripcion))) {
         $mensaje .= "Se guardó correctamente en la base de datos<br>";
      }
      else {
         $mensaje .= "ERROR: No pude guardar en la base de datos<br>";
         $error = true;
      }
    }
  }

?><!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8" />
  <link rel="shortcut icon" href="favicon.ico" /><!-- 16x16 píxeles -->
  <title>Insertar foto</title>
  <style>
    body { background-color:#eee; }
    fieldset { width:20em; }
    fieldset p { margin:0 0 1em 0; }
    fieldset label { display:block; }
    input[type="text"], textarea { width:100%; }
    label:after { content:": "; color:#999;  }
    .mal { background-color:#c00; color:#fff; padding:1em; display:inline-block; }
    .bien { background-color:#cfc; padding:1em; display:inline-block; }
    textarea { height:10em; }
  </style>
</head>
<body>

  <?php /*
   if ($error) { echo 'mal'; } else { echo 'bien'; }
   echo $precio > 100 ? 0.05 : 0.02; ?>
   echo $mensaje == '' ? 0.05 : 0.02;
  */ ?>

  <h1>Insertar foto</h1>

  <?php if (!empty($mensaje)): ?>
    <div class="<?php echo $error ? 'mal' : 'bien'; ?>">
      <?php echo $mensaje; ?>
    </div>
  <?php endif; ?>

  <form
    action="insertar_foto.php"
    method="post"
    enctype="multipart/form-data" >
    <p>
      <label for="foto">Foto</label>
      <input type="file" name="foto" id="foto" />
    </p>
    <fieldset>
      <legend>Detalles</legend>
      <p>
        <label for="autor">Autor</label>
        <input type="text" name="autor" id="autor" />
      </p>
      <p>
        <label for="fecha">Fecha</label>
        <input type="text" name="fecha" id="fecha"
          placeholder="aaaa-mm-dd"
          value="<?php echo $fecha; ?>"
        />
      </p>
      <p>
        <label for="descripcion">Descripción</label>
        <textarea name="descripcion" id="descripcion"></textarea>
      </p>
    </fieldset>
    <p>
      <input type="submit" value="Subir" />
    </p>
  </form>
</body>
</html>
