<?php
    require_once('../template.php');
?><!DOCTYPE html>
<html>
<head>
<meta charset="utf-8" />
<title>PHP 21</title>
</head>
<body>
<h1>PHP 21</h1>
<h2>Ejercicio galería de fotos</h2>
<ul>
    <li><?php enlazar('fotos_ejercicio.txt', 'Enunciado del ejercicio'); ?></li>
    <li><?php enlazar('fotos.sql', 'Tabla de fotos'); ?></li>
    <li><?php enlazar('insertar_foto.php', 'Insertar y subir una foto'); ?></li>
    <li><?php enlazar('fotos.php', 'Galería de las fotos subidas'); ?></li>
    <li><?php enlazar('fotos.css', 'Hoja de estilos'); ?></li>
</ul>

</body>
</html>
