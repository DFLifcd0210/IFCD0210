<?php
  // http://localhost/php/dia21/fotos.php

  require_once "../conexion.php";
  $acme = new PDO("mysql:host=$servidor;dbname=$basedatos", $usuario, $clave);
  $acme->exec("SET CHARACTER SET utf8");

  $datos = $acme->query("SELECT * FROM fotos ORDER BY foto");

?><!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8" />
  <link rel="shortcut icon" href="favicon.ico" />
  <link rel="stylesheet"    href="fotos.css" />
  <title>Galería de fotos</title>
</head>
<body>
  <header>
    <h1>Galería de fotos</h1>
  </header>
  <section>
    <?php
      foreach($datos as $fila) {
        echo "<article>";
        echo " <h2>$fila[foto]</h2>";
        echo " <p class=\"imagen\"><img src=\"fotos/$fila[foto]\" width=\"300\" /></p>";
        echo " <p class=\"descarga\"><a href=\"fotos/$fila[foto]\" target=\"_blank\">Descargar</a></p>";
        echo " <p class=\"detalle\">por <strong>$fila[autor]</strong> el $fila[fecha]</p>";
        echo " <p class=\"descripcion\">$fila[descripcion]</p>";
        echo "</article>";
      }
    ?>
  </section>
  <footer>
    <p>Acme &copy; 2014-<?php echo date('Y'); ?></p>
  </footer>
</body>
</html>
