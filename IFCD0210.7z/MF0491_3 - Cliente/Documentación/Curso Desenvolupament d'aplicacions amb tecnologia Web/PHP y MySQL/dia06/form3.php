<?php
/*
    EJERCICIO:
    
    form3.html
        Un formulario donde escribir un número que se enviará a form3.php
    form3.php
        Adivinar el número secreto
        - Si el número envíado es el número secreto mostrar "LO ADIVINASTE"
        - Si el número es mayor que el secreto mostrar "TE HAS PASADO"
        - Si el número es menor que el secreto mostrar "TE HAS QUEDADO CORTO"
*/
    $secreto = 91;

    if (!isset($_POST['numero'])) {
        header("Location: form3.html");
        exit();
    }

    $numero = $_POST['numero'];
    if ($numero == $secreto) { $mensaje = "Lo adivinaste!!!"; }
    elseif ($numero > $secreto) { $mensaje = "Te has pasado"; }
    else { $mensaje = "Te has quedado corto"; }
    
    echo $mensaje;
