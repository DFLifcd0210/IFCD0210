<?php
/*
  Función que da el signo de un número
    Si el número es positivo da 'positivo'
    Si el número es negativo da 'negativo'
    Si el número es 0 da 'cero'

  http://localhost/dia06/repaso2.php
*/

echo signoNumero(34).'<br>';
echo signoNumero(-8).'<br>';
echo signoNumero(0).'<br>';

function signoNumero ($numero) {
    if ($numero > 0) {
        $signo = 'positivo';
    }
    elseif ($numero < 0) {
        $signo = 'negativo';
    }
    else {
        $signo = 'cero';
    }
    return $signo;
}

function signoNumeroV2 ($numero) {
    if ($numero > 0) { return 'positivo'; }
    if ($numero < 0) { return 'negativo'; }
    return 'cero';
}







