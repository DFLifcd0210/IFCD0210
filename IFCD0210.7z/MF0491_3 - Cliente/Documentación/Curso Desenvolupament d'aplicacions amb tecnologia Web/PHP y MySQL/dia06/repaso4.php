<?php
/*
  Función que da la posición de un texto dentro del array
    - Si no encuentra el texto da 0
    - Si lo encuentra da la posición empezando por 1

  http://localhost/dia06/repaso4.php
*/

$asistencia = array(
    'Alex','David',
    'Angel','Paola',
    'Katiuzka',
    'Julio','Pep','Laura','Miguel'
);

echo posicionEnLista($asistencia, 'Angel').'<br>'; // Imprimirá 3
echo posicionEnLista($asistencia, 'Laura').'<br>'; // Imprimirá 8
echo posicionEnLista($asistencia, 'Bryan').'<br>'; // Imprimirá 0


function posicionEnLista ($lista, $texto) {
    $posicion = 1;
    foreach ($lista as $valor) {
        if ($texto == $valor) {
            return $posicion;
        }
        $posicion++;
    }
    return 0;
}




