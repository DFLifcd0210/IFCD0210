<?php
/*
  Función que calcule el área
  de un triángulo.
    área = (base * altura) / 2

  http://localhost/dia06/repaso1.php
*/

$area = calculaAreaTriangulo(23,11);
echo "El área del triángulo es $area m<sup>2</sup>";

function calculaAreaTriangulo($base, $altura) {
    $area = $base * $altura / 2;
    return $area;
}

