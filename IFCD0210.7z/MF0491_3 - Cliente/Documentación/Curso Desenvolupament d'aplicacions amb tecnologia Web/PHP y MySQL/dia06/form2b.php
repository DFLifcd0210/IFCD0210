<?php   
   // Si no vengo de un formulario me voy al formulario
   if (empty($_POST)) {
       header("Location: form2b.html");
       exit();
   }
   
   // Recuperar los datos del formulario
   $campos = explode(',', "apodo,telefono,clave");
   foreach ($campos as $campo) { 
        $$campo = $_POST[$campo]; 
   }
   
   // Comprobar que datos faltan
   $incompleto = array();
   foreach ($campos as $campo) {
        if (empty($$campo)) { 
            $incompleto[] = "Falta $campo"; 
        }
   }
   if (!empty($incompleto)) {
       echo implode("<br>", $incompleto);
       exit();
   }
   
   // Tengo todos los datos
   echo "Apodo=$apodo<br>Teléfono=$telefono<br>Contraseña=$clave"; 
   
?>    



