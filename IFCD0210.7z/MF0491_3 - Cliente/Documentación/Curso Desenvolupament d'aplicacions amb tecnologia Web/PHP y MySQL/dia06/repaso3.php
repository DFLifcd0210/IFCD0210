<?php
/*
  Función que busca si existe un texto dentro de un array
    - Da true si encuentra el texto
    - Da false si no encuentra el texto

  http://localhost/dia06/repaso3.php
*/

$asistencia = array('Alex','David','Angel','Katiuzka','Paola','Julio','Pep','Laura','Miguel');

if (estaListado($asistencia, 'David')) {
    echo "David está<br>";
} else {
    echo "David no está<br>";
}

if (estaListado($asistencia, 'Bryan')) {
    echo "Bryan está<br>";
} else {
    echo "Bryan no está<br>";
}

function estaListado ($lista, $texto) {
    foreach($lista as $valor) {
        //echo "¿$texto es $valor? ";
        if ($texto == $valor) {
            //echo "sí<br>";
            return true;
        }   
        else {
            //echo "no!<br>";        
        }
    }
    //echo "$texto no encontrado!<br>";
    return false;     
}








