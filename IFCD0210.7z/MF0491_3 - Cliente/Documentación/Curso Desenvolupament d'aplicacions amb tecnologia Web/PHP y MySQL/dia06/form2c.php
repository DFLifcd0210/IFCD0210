<?php   
   // Si no vengo de un formulario me voy al formulario
   if (empty($_POST)) {
       header("Location: form2c.html");
       exit();
   }
      
   // Comprobar que datos faltan
   $incompleto = array();
   foreach ($_POST as $name=>$value) {
        if (empty($value)) { 
            $incompleto[] = "Falta $name"; 
        }
   }
   if (!empty($incompleto)) {
       echo implode("<br>", $incompleto);
       exit();
   }
   
   // Tengo todos los datos
   echo "Datos: ".implode(",", $_POST); 
   
?>    



