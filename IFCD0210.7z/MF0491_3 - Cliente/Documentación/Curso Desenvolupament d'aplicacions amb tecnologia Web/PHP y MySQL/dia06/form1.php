<?php
    // ¿Venimos del formulario?
    if (isset($_POST['apodo']) 
     && isset($_POST['telefono'])
     && isset($_POST['clave'])
    ){
        // Recoge los datos del formulario (todo lo que tenga name)
        $apodo = $_POST['apodo'];
        $telefono = $_POST['telefono'];
        $clave = $_POST['clave'];
        
        if (empty($apodo)) {
            echo "Falta el apodo<br>";
        }
        elseif (empty($telefono)) {
            echo "Falta el teléfono<br>";
        }
        elseif (empty($clave)) {
            echo "Falta la contraseña<br>";
        }
        else {
           echo "El teléfono de $apodo es $telefono y su contraseña $clave<br>";
        }    
    }
    else {        
        header("Location: form1.html");        
    }
?>    



