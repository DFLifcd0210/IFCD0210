<?php   
   // Si no vengo de un formulario me voy al formulario
   if (! isset($_POST['enviado'])) {
       header("Location: form2.html");
       exit();
   }
   
   // Recuperar los datos del formulario
   $apodo = $_POST['apodo'];
   $telefono = $_POST['telefono'];
   $clave = $_POST['clave'];
   
   // Comprobar que datos faltan
   $incompleto = array();
   if (empty($apodo)) { $incompleto[] = "Falta el apodo"; }
   if (empty($telefono)) { $incompleto[] = "Falta el teléfono"; }
   if (empty($clave)) { $incompleto[] = "Falta la contraseña"; }   
   if (count($incompleto) != 0) {
       echo implode("<br>", $incompleto);
       exit();
   }
   
   // Tengo todos los datos
   echo "Apodo=$apodo, Teléfono=$telefono, Contraseña=$clave";
   
?>    



