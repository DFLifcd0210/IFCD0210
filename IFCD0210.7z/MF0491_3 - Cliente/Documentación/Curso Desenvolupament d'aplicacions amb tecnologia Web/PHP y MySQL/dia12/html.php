<?php
/*
    http://localhost/dia11/class-html.php
    
    EJERCICIO:
       0) Función negrita (texto)
                <strong>texto</strong>
       1) Función cursiva (texto)
                <em>texto</em>
       2) Función enlace (texto, vinculo)
                <a href="vinculo">texto</a>
       3) Función imagen (fichero)
                <img src="fichero" />
       4) Función listaEnlaces (array asociativo)
                <ul>
                  <li><a href="vinculo">texto</a></li>
                  ...
                </ul>
       5) Función tabla (array de arrays)
                <table>
                    <tr><td>...</td><td>...</td></tr>
                    <tr><td>...</td><td>...</td></tr>
                    ...
                </table>
*/

class HTML {
    
    public static function salto() {
        return '<br />';
    }

    // 0
    public static function negrita($texto) {
        $html = '';
        $html .= '<strong>';
        $html .= htmlentities($texto);
        $html .= '</strong>';
        return $html;
    }
    
    // 1
    public static function cursiva($texto) {
        $html = '';
        $html .= '<em>';
        $html .= htmlentities($texto);
        $html .= '</em>';
        return $html;
    }    

    // 2
    public static function enlace ($texto, $vinculo) {
        $html = '';
        $html .= '<a href="';
        $html .= $vinculo;
        $html .= '">';
        $html .= htmlentities($texto);
        $html .= '</a>';
        return $html;
    }
    
    // 3
    public static function imagen ($fichero) {
        $html = '';
        $html .= '<img src="';
        $html .= $fichero;
        $html .= '" />';
        return $html;
    }
    
    // 4
    public static function listaEnlaces ($lista) {
        $html = '';
        $html .= '<ul>';
        foreach ($lista as $texto => $enlace) {
            $html .= '<li>';
            $html .= self::enlace($texto, $enlace);
            $html .= '</li>';
        }
        $html .= '</ul>';
        return $html;        
    }
    
    // 5
    public static function tabla ($tabla) {
        $html = '';
        $html .= '<table border="1">';
        foreach ($tabla as $fila) {
            $html .= '<tr>';
            foreach ($fila as $texto) {
                $html .= '<td>';
                $html .= htmlentities($texto);
                $html .= '</td>';
            }
            $html .= '</tr>';
        }        
        $html .= '</table>';
        return $html;
    }   
    

} // Fin HTML

echo HTML::negrita('<Hola>');
echo HTML::salto();
echo HTML::cursiva('Texto');
echo HTML::salto();
echo HTML::enlace('<<Wikipedia>>', 'http://es.wikipedia.org/');
echo HTML::salto();
echo HTML::imagen('paisaje.jpg');
echo HTML::salto();
echo HTML::listaEnlaces(array(
    'Google'=> 'http://www.google.com/',
    'PHP'=> 'http://php.net/',
    'MySQL'=> 'http://www.mysql.com/dev/',
    'W3Schools'=> 'http://www.w3schools.com/',
));
echo HTML::salto();
echo HTML::tabla(array(
    array('ID', 'PAIS', 'CAPITAL'),
    array(1, 'Francia', 'París'),
    array(2, 'Italia', 'Roma'),
    array(3, 'Grecia', 'Atenas'),
    array(4, 'Portugal', 'Lisboa'),
));
