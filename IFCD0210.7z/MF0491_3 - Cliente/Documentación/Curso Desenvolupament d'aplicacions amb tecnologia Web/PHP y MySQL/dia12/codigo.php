<?php
/*
    Código HTML
        http://localhost/dia12/codigo.php
        
    Funciones:
        htmlentities
        htmlspecialchars
        
    Entidades HTML:
        < = &lt;
        > = &gt;
        " = &quote;
        & = &amp;   
*/    

    echo "Este texto está <strong>resaltado</strong><br>";
    
    echo "Este texto está &lt;strong&gt;resaltado&lt;/strong&gt;<br>";
    
    echo htmlentities("Este texto está <strong>resaltado</strong>");
    
    //echo "La etiqueta <br> se va a la línea siguiente";
    echo htmlentities("La etiqueta <br> se va a la línea siguiente");
    
    