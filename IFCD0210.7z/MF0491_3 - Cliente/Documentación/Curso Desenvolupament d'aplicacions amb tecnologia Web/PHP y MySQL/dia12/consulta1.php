<?php
  // http://localhost/dia12/consulta1.php
  
  require_once("class-html.php");
  require_once("class-bdacme.php");
  
  $sql = "SELECT * FROM paises";
  
  BdAcme::conectar();
  $datos = BdAcme::consultar($sql);
  $tabla = HTML::tabla($datos);

?><!DOCTYPE html>
<html>
<head>
  <meta charset="utf8" />
  <title>Consulta 1</title>
</head>
<body>
  <h1>Consulta 1</h1>
  
  <?php echo $tabla; ?>
  
</body>
</html>  