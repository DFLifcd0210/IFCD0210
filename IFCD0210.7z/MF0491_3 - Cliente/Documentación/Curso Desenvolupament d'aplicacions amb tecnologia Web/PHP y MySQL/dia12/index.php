<?php
    require_once('../template.php');
?><!DOCTYPE html>
<html>
<head>
<meta charset="utf-8" />
<title>PHP 12</title>
</head>
<body>
<h1>PHP 12</h1>
<h2>Repaso </h2>
<ul>
    <li><?php enlazar('concatenar.php', 'Concatenar en varias instrucciones'); ?></li>
    <li><?php enlazar('codigo.php', 'Codificar HTML', 'Funciones: htmlentities y         htmlspecialchars'); ?></li>
    <li><?php enlazar('html.php', 'Clase para generar HTML', 'Lista de enlaces y tabla'); ?></li>
</ul>
<h2>BD en PHP</h2>
<ul>   
    <li><?php enlazar('bdacme.php', 'Conectar con MySQL', 'Uso de la clase PDO'); ?></li>
    <li><?php enlazar('consulta1.php', 'Una consulta de países'); ?><br />
      <?php enlazar('consulta2.php', 'Dos consulta simultáneas'); ?>
      <ul>
          <li><?php enlazar('class-bdacme.php', 'Clase para conectar con MySQL'); ?></li>
          <li><?php enlazar('class-html.php', 'Clase para generar HTML'); ?></li>
      </ul>
    </li>
</ul>
</body>
</html>
