<?php
  // http://localhost/dia12/consulta2.php
  
  /*
     SQL --> datos --> HTML
     "SELECT ..."  --> array en arrays --> <table><tr><td>..
  
  */
  
  require_once("class-html.php");
  require_once("class-bdacme.php");
  
  $sql1 = "SELECT * FROM paises";
  $sql2 = "SELECT * FROM users";
  
  BdAcme::conectar();
  
  $datos = BdAcme::consultar($sql1);
  $tabla1 = HTML::tabla($datos);
  
  $datos = BdAcme::consultar($sql2);
  $tabla2 = HTML::tabla($datos);

?><!DOCTYPE html>
<html>
<head>
  <meta charset="utf8" />
  <title>Consulta 2</title>
</head>
<body>
  <h1>Base de datos</h1>
  
  <h2>Tabla países</h2>  
  <?php echo $tabla1; ?>
  
  <h2>Tabla usuarios</h2>  
  <?php echo $tabla2; ?>
</body>
</html>  