<?php 
/*
    Concatenar
    http://localhost/dia12/concatenar.php
*/    

$texto = '';
$texto = $texto . 'Un';
$texto = $texto . ' día';
$texto = $texto . ' caluroso';
$texto = $texto . '<br>';
echo $texto;

$frase = '';
$frase .= 'Hoy';
$frase .= ' hace';
$frase .= ' mucho';
$frase .= ' calor';
$frase .= '<br>';
echo $frase;

$oracion = array();
$oracion[]= 'Parece';
$oracion[]= 'que';
$oracion[]= 'va';
$oracion[]= 'a';
$oracion[]= 'llover';
$oracion[]= '<br>';
echo implode(' ', $oracion);