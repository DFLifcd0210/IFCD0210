<?php
/*
    Conexión con la BD
        http://localhost/dia12/class-bdacme.php

    Tres formas de conexión:
        - Funciones mysql_
        - Funciones o clases mysqli_
        - Clase PDO (PHP Data Objects)
*/
/*
$pdo = new PDO("mysql:host=localhost;dbname=bdacme", 'bdacme', 'bdacme');
$pdo->exec("SET CHARACTER SET utf8");
*/

require_once "../conexion.php";

class BdAcme {

    /*const SERVIDOR = 'localhost';
    const BASE_DATOS = 'bdacme';
    const USUARIO = 'bdacme';
    const CLAVE = 'bdacme';*/

    private static $pdo;

    /*public static function conectar() {
        $cadenaConexion = "mysql:host=".self::SERVIDOR.";dbname=".self::BASE_DATOS;
        self::$pdo = new PDO($cadenaConexion, self::USUARIO, self::CLAVE);
        self::$pdo->exec("SET CHARACTER SET utf8");
    }*/

    public static function conectar() {
      global $servidor, $basedatos, $usuario, $clave;
      self::$pdo = new PDO("mysql:host=$servidor;dbname=$basedatos", $usuario, $clave);
      self::$pdo->exec("SET CHARACTER SET utf8");
    }

    public static function consultar($sql) {
        $datos = self::$pdo->query($sql, PDO::FETCH_ASSOC);
        return $datos;
    }

} // Fin BdAcme

/*--
BdAcme::conectar();
$tabla = BdAcme::consultar("SELECT * FROM paises");

foreach ($tabla as $fila) {
    foreach ($fila as $celda) {
        echo "$celda, ";
    }
    echo "<br>";
}
---*/

