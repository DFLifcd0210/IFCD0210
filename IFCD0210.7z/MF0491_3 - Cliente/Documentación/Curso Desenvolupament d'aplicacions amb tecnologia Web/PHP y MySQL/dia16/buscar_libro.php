<?php

    $mensaje = '';
    $busqueda = '';
    $datos = array();

    if (!empty($_GET)) { // Se pulsó el botón buscar

        $busqueda = $_GET['busqueda'];

        if (empty($busqueda)) {
            $mensaje = "Falta que pongas lo que quieres buscar";
        }

        if (empty($mensaje)) { // Sí que hay algo que buscar
            require_once "../conexion.php";
            $bd = new PDO("mysql:host=$servidor;dbname=$basedatos", $usuario, $clave);
            $bd->exec("SET CHARACTER SET utf8");

            // El título contiene el texto de la búsqueda
            $plantilla = $bd->prepare("SELECT * FROM libros WHERE titulo LIKE ?");
            $plantilla->execute(array("%$busqueda%"));
            $datos = $plantilla->fetchAll();

            $mensaje = "He encontrado ".count($datos). " libro(s) que cumplen el criterio de búsqueda";
        }
    }


?><!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8" />
  <title>Buscar libro</title>
  <style>
    div.libro {
        display:inline-block;
        padding:1em 2em;
        margin:0.5em 1em;
        border:2px solid #ccc;
    }
    div.libro strong {
        font-weight:normal;
        background-color:#ff0;
    }
  </style>
</head>
<body>
  <h1>Buscar libro</h1>

  <p><?php echo $mensaje; ?></p>

  <h2>Fórmulario de búsqueda</h2>
  <form
    action="buscar_libro.php"
    method="GET" >
        <input
            type="text"
            name="busqueda"
            value="<?php echo $busqueda; ?>"
            autofocus="on"
            placeholder="Búsqueda" />
         <input
            type="submit"
            value="Buscar" />
  </form>

  <h2>Listado de libros</h2>
  <?php
    foreach ($datos as $fila) {
       $titulo = $fila['titulo'];
       $titulo = str_ireplace($busqueda, "<strong>$busqueda</strong>", $titulo);
       echo '<div class="libro">';
       echo "<h3>$titulo</h3>";
       echo "<p>$fila[paginas] págs.</p>";
       echo "<p>$fila[publicacion]</p>";
       echo '</div>';
    }
  ?>

</body>
</html>
