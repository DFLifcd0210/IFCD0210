<?php
    require_once('../template.php');
?><!DOCTYPE html>
<html>
<head>
<meta charset="utf-8" />
<title>PHP 16</title>
</head>
<body>
<h1>PHP 15</h1>
<h2>Tabla libros: Insertar/Listar/Buscar</h2>
<ul>
    <li><?php enlazar('libros_ejercicio.txt', 'Enunciado del ejercicio'); ?></li>
    <li><?php enlazar('insertar_libro.php', 'Insertar una nuevo libro'); ?></li>
    <li><?php enlazar('listar_libros.php', 'Listado de libros'); ?></li>
    <li><?php enlazar('buscar_libro.php', 'Buscar un libro por su título'); ?></li>
</ul>

</body>
</html>
