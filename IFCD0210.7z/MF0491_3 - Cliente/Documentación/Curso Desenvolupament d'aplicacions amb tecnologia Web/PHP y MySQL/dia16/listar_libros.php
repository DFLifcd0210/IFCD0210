<?php
    require_once "../conexion.php";
    $bd = new PDO("mysql:host=$servidor;dbname=$basedatos", $usuario, $clave);
    $bd->exec("SET CHARACTER SET utf8"); // Usa el Unicode

    $sql = "SELECT titulo, paginas, publicacion FROM libros ORDER BY titulo";
    $datos = $bd->query($sql);

    /*
        "2015-04-16"
            --> array('2015', '04', '16')
            --> array('16', '04', '2015')
            --> "16-04-2015"
    */
    function invertirFecha($fecha) {
        $elementos = explode('-', $fecha); // Convierte un string en un array
        $elementos = array_reverse($elementos); // Le da la vuelta al array
        return implode('-', $elementos); // Convierte un array en un string
    }

?><!DOCTYPE html>
<html>
<head>
  <title>Listado de todos los libros</title>
  <meta charset="utf-8" />
</head>
<body>
  <h1>Listado de todos los libros</h1>
  <?php
    echo "<ol>";
    foreach ($datos as $fila) {
        $fecha = invertirFecha($fila['publicacion']);
        echo "<li>";
        echo " <h2>$fila[titulo]</h2>";
        echo " <p><strong>$fila[paginas]</strong> páginas</p>";
        echo " <p>Fecha de publicación: <strong>$fecha</strong></p>";
        echo "</li>";
    }
    echo "</ol>";
  ?>

</body>
</html>
