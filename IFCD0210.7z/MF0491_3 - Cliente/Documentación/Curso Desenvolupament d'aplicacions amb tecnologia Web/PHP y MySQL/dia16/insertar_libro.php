<?php
    // http://localhost/dia16/insertar_libro.php

    /*
        $_POST
            Es un array que contiene lo enviado en el formulario.
            Si no se envio es un array vacío.
            Es array asociativo donde las claves son los name del formulario.
            Y los valores es lo que escribió el usuario.
    */

    // Inicialización de las variables porque se usan en el BODY
    $mensaje = "";
    $titulo = "";
    $paginas = "";
    $publicacion = "";

    if (!empty($_POST)) { // ¿Has pulsado el botón de enviar?

        $titulo = $_POST['titulo'];
        $paginas = $_POST['paginas'];
        $publicacion = $_POST['publicacion'];

        // Filtro de datos
        if (empty($titulo)) { // ¿No has escrito nada en título?
            $mensaje .= "Falta el título<br>";
        }
        if (empty($paginas)) { // ¿No has escrito las páginas?
            $mensaje .= "Faltan las páginas<br>";
        }
        if (empty($publicacion)) { // ¿No has publicación?
            $mensaje .= "Falta la fecha de publicación<br>";
        }

        if (empty($mensaje)) { // ¿Todos los campos tienen datos?
            require_once "../conexion.php";
            $bd = new PDO("mysql:host=$servidor;dbname=$basedatos", $usuario, $clave);
            $bd->exec("SET CHARACTER SET utf8"); // Usa el Unicode

            $plantillaSQL = $bd->prepare("INSERT INTO libros(titulo, paginas, publicacion) VALUES (?,?,?)"); // Crea una plantilla SQL
            $estaInsertado = $plantillaSQL->execute(array($titulo, $paginas, $publicacion)); // Añade el libro a la base de datos. Si funcionó retorna TRUE

            if ($estaInsertado) {
                $id = $bd->lastInsertId(); // Obtengo el id del nuevo libro
                $mensaje = "El libro ha sido insertado correctamente con el id=$id";
            }
            else {
                $mensaje = "No se pudo insertar, puede que esté duplicado el título";
            }
        }
    }

?><!DOCTYPE html>
<html>
<head>
  <title>Insertar un nuevo libro</title>
  <meta charset="utf-8" />
</head>
<body>
  <h1>Insertar un nuevo libro</h1>

  <p><?php echo $mensaje; ?></p>

  <form
    action="insertar_libro.php"
    method="POST">

    <p>
        <label for="titulo">Título:</label><br>
        <input
            type="text"
            name="titulo"
            id="titulo"
            value="<?php echo $titulo; ?>"
            maxlength="32"
            autofocus="on" />
    </p>
    <p>
        <label for="paginas">Número de páginas:</label><br>
        <input
            type="text"
            name="paginas"
            id="paginas"
            value="<?php echo $paginas; ?>"
            maxlength="4"  />
    </p>
        <p>
        <label for="publicacion">Fecha de publicación:</label><br>
        <input
            type="text"
            name="publicacion"
            id="publicacion"
            value="<?php echo $publicacion; ?>"
            maxlength="10"
            placeholder="aaaa-mm-dd" />
    </p>

    <p>
        <input type="submit" value="Insertar" />
    </p>

  </form>

  <hr>Chivato de $_POST: <pre><?php print_r($_POST); ?></pre>

</body>
</html>
