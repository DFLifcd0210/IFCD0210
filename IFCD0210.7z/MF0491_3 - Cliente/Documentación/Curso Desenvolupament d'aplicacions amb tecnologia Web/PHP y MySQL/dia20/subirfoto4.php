<?php 
  // http://localhost/php/dia20/subirfoto4.php 
  
  $mensaje = '';
  $destino = '';
  
  if (!empty($_FILES)) { // Se ha subido algún archivo
    
    if ($_FILES['foto']['error'] == 0) { // No hay error
    
      if ($_FILES['foto']['type'] != 'image/jpeg') {
        $mensaje = "Sólo se admiten fotos JPG";
      }
      if ($_FILES['foto']['size'] > 1000000) {
        $mensaje = "El archivo es más grande de 1 MB";
      }
    
      if ($mensaje == '') {
        $destino = "fotos/" . $_FILES['foto']['name'];
      
        move_uploaded_file(
          $_FILES['foto']['tmp_name'],
          $destino
        );
      }
    
    }
    else {
      $mensaje = "Error al subir el archivo";      
    }    
  }  
  
?><!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8" />
  <title>Subir foto 4</title>
</head>
<body>
  <h1>Subir foto 4</h1>
  <p>
    <?php echo $mensaje; ?>
  </p>
  <form 
    action="subirfoto4.php"
    method="post"
    enctype="multipart/form-data" >
    <p>Autor: <input type="text" name="autor" /></p>
    <p>Foto: <input type="file" name="foto" /></p>
    <p><input type="submit" value="Subir" /></p>    
  </form> 
  <p>
    <img src="<?php echo $destino; ?>" />
  </p> 
</body>
</html>