<?php 

  // http://localhost/php/dia20/subirfoto1.php 
  
  
?><!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8" />
  <title>Subir foto 1</title>
</head>
<body>
  <h1>Subir foto 1</h1>
  <form 
    action="subirfoto1.php"
    method="post"
    enctype="multipart/form-data" >
    <p>Autor: <input type="text" name="autor" /></p>
    <p>Foto: <input type="file" name="foto" /></p>
    <p><input type="submit" value="Subir" /></p>    
  </form> 
 
<hr />
  
<pre><?php 
  print_r($_POST); 
  print_r($_FILES);
?></pre>
  
</body>
</html>