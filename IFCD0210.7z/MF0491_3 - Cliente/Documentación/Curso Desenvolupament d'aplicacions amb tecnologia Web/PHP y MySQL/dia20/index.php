<?php
    require_once('../template.php');
?><!DOCTYPE html>
<html>
<head>
<meta charset="utf-8" />
<title>PHP 20</title>
</head>
<body>
<h1>PHP 20</h1>
<h2>Subir archivos</h2>
<ul>
    <li><?php enlazar('apunts.html', 'Apuntes'); ?></li>
    <li><?php enlazar('subirfoto1.php', 'Subir una foto', 'Ver la variable $_FILES'); ?></li>
    <li><?php enlazar('subirfoto2.php', 'Ídem usando la función move_uploaded_file'); ?></li>
    <li><?php enlazar('subirfoto3.php', 'Ídem usando el nombre de la foto'); ?></li>
    <li><?php enlazar('subirfoto4.php', 'Ídem con filtros de tipo y tamaño'); ?></li>
</ul>
</body>
</html>
