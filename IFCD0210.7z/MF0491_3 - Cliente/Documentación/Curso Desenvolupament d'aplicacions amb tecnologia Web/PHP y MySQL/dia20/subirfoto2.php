<?php 
  // http://localhost/php/dia20/subirfoto2.php 
  
  $mensaje = '';
  
  if (!empty($_FILES)) { // Se ha subido algún archivo
    
    if ($_FILES['foto']['error'] == 0) { // No hay error
    
      move_uploaded_file(
        $_FILES['foto']['tmp_name'],
        "fotos/1.jpg"
      );
    
    }
    else {
      $mensaje = "Error al subir el archivo";      
    }    
  }  
  
?><!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8" />
  <title>Subir foto 2</title>
</head>
<body>
  <h1>Subir foto 2</h1>
  <p>
    <?php echo $mensaje; ?>
  </p>
  <form 
    action="subirfoto2.php"
    method="post"
    enctype="multipart/form-data" >
    <p>Autor: <input type="text" name="autor" /></p>
    <p>Foto: <input type="file" name="foto" /></p>
    <p><input type="submit" value="Subir" /></p>    
  </form> 
  <p>
    <img src="fotos/1.jpg" />
  </p> 
</body>
</html>