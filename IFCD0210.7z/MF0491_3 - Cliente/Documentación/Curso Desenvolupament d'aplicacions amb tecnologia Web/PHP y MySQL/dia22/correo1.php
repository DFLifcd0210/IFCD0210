<?php
/*
  http://localhost/php/dia22/correo1.php
  
  La función mail que viene dentro de PHP 
  es el método más fácil para enviar un correo.
  
  En un servidor de pago seguramente funcionaría
  porque estaría ya configurado correctamente el SMTP.
  
  En xampp no funciona porque no está bien configurado
  el protocolo SMTP (Send Mail Transfer Protocol)  
  
  Para configurar bien el SMTP hay que editar el 
  archivo "php.ini" y otro que se llama "sendmail.ini"
  
  En la carpeta c:\xampp\mailoutput queda
  un registro de los correos que se intentan enviar.
*/  
  
  $destinatario = "fco.cascales@gmail.com";
  $asunto = "Prueba de correo";
  $mensaje = "Texto de dentro con fecha ".date('Y-m-d h:i:s');

  $ok = mail($destinatario, $asunto, $mensaje); 
  
  if ($ok) {
    echo "Mensaje enviado";
  }
  else {
    echo "ERROR al enviar";
  }
  