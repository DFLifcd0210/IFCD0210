<?php
/*
  Enviar los datos del formulario de contacto
  al administrador de la web
  
  http://localhost/php/dia22/correo3.php
*/  
  
  $mensaje = "";

  if (!empty($_POST)) { // ¿Hay datos del formulario?
    
    // Recuperar los datos del formulario
    $nombre = $_POST['nombre'];
    $correo = $_POST['correo'];
    $comentario = $_POST['comentario'];
    
    // Filtrar los datos del formulario
    
    // Quitar espacios en blanco sobrantes que hubiese al principio y al final
    $nombre = trim($nombre);
    $correo = trim($correo);
    $comentario = trim($comentario);
    
    // Quitar etiquetas HTML que pudiese haber
    $nombre = strip_tags($nombre);
    $correo = strip_tags($correo);
    $comentario = strip_tags($comentario);
    
    // Limitar la longitud del campo
    $nombre = substr($nombre, 0, 20);
    $correo = substr($correo, 0, 50);
    $comentario = substr($comentario, 0, 1000);
    
    // Comprobar que sea correcto el correo
    if (!filter_var($correo, FILTER_VALIDATE_EMAIL)) {
      $mensaje = "El correo es incorrecto";
    }
    
    // Campos requeridos
    if (empty($nombre) || empty($correo) || empty($comentario)) {
      $mensaje = "Falta el nombre, correo o comentario";
    }
    
    if (empty($mensaje)) {
      // Datos para enviar el correo
      $destinatario = "fco.cascales@gmail.com";
      $asunto = "Contacto desde la web ACME";
      $cuerpo = "nombre:\n$nombre\n\n".
        "correo:\n$correo\n\n".
        "comentario:\n$comentario\n\n";

      $ok = mail($destinatario, $asunto, $cuerpo);
      if ($ok) {
        $mensaje = "Su mensaje ha sido enviado";
      }
      else {
        $mensaje = "Esto es embarazoso, no pude enviar el correo";
      }
    }    
  }
  
?><!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8" />
  <title>Correo 3</title>
  <style>
    body { background-color:#ccc; }
    label { display:block; }
    textarea { width:50em; height:10em; }
  </style>
</head>
<body>
  <h1>Correo 3</h2>
  <h2>Formulario de contacto</h2>
  <p><?php echo $mensaje; ?></p>
  <form action="correo3.php"
        method="post">        
    <p>
       <label>Nombre:</label>
       <input type="text" 
              name="nombre" />
    </p>
    <p>
       <label>Correo electrónico:</label>
       <input type="text" 
              name="correo" />
    </p>
    <p>
       <label>Comentario:</label>
       <textarea name="comentario"></textarea>
    </p>
    <p>
      <input type="submit" 
             value="Enviar" />
    </p>
  </form>
</body>
</html>
  