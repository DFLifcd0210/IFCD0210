<?php
/*
  Enviar los datos del formulario de contacto
  al administrador de la web
  
    1) Comprobar que hay datos enviados
    2) Recoger los datos del formulario
    3) Comprobar que no estén vacíos 
    4) Enviar el correo electrónico

  http://localhost/php/dia22/correo2.php
*/  
  
  $mensaje = "";

  if (!empty($_POST)) { // ¿Hay datos del formulario?
    
    // Recuperar los datos del formulario
    $nombre = $_POST['nombre'];
    $correo = $_POST['correo'];
    $comentario = $_POST['comentario'];
    
    if (empty($nombre) || empty($correo) || empty($comentario)) {
      $mensaje = "Falta el nombre, correo o comentario";
    }
    
    if (empty($mensaje)) {
      // Datos para enviar el correo
      $destinatario = "fco.cascales@gmail.com";
      $asunto = "Contacto desde la web ACME";
      $cuerpo = "nombre=$nombre\n".
        "correo=$correo\n".
        "comentario=$comentario\n";

      $ok = mail($destinatario, $asunto, $cuerpo);
      if ($ok) {
        $mensaje = "Su mensaje ha sido enviado";
      }
      else {
        $mensaje = "Esto es embarazoso, no pude enviar el correo";
      }
    }    
  }
  
?><!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8" />
  <title>Correo 2</title>
  <style>
    body { background-color:#ccc; }
    label { display:block; }
    textarea { width:50em; height:10em; }
  </style>
</head>
<body>
  <h1>Correo 2</h2>
  <h2>Formulario de contacto</h2>
  <p><?php echo $mensaje; ?></p>
  <form action="correo2.php"
        method="post">        
    <p>
       <label>Nombre:</label>
       <input type="text" 
              name="nombre" />
    </p>
    <p>
       <label>Correo electrónico:</label>
       <input type="text" 
              name="correo" />
    </p>
    <p>
       <label>Comentario:</label>
       <textarea name="comentario"></textarea>
    </p>
    <p>
      <input type="submit" 
             value="Enviar" />
    </p>
  </form>
</body>
</html>
  