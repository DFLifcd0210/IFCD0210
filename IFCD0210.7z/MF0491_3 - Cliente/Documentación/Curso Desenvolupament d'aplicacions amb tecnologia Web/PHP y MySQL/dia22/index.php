<?php
    require_once('../template.php');
?><!DOCTYPE html>
<html>
<head>
<meta charset="utf-8" />
<title>PHP 22</title>
</head>
<body>
<h1>PHP 22</h1>
<h2>Correo</h2>
<ul>
    <li><?php enlazar('apuntes_correo.txt', 'Apuntes correo'); ?></li>
    <li><?php enlazar('correo1.php', 'Correo con la función mail'); ?></li>
    <li><?php enlazar('correo2.php', 'Formulario de contacto'); ?></li>
    <li><?php enlazar('correo3.php', 'Ídem con filtros', 'Funciones: trim, strip_tags, substr, filter_var'); ?></li>
    <li><?php enlazar('correo4.php', 'Ídem con encabezados', 'Formato HTML, Reply-to, From, Cc, Bcc'); ?></li>
</ul>
<h2>Dominio y hospedaje</h2>
<ul>
    <li><?php enlazar('apuntes_publicar.txt', 'Apuntes de dominio y hospedaje'); ?></li>    
    <li><a href="http://nixiweb.com">Nixiweb</a> &mdash; Hospedaje gratuito</a></li>
    <li><a href="http://uni.me">Uni.me</a> &mdash; Dominios gratuito</a></li>    
</ul>

</body>
</html>
