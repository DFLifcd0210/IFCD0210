<?php
    require_once('../template.php');
?><!DOCTYPE html>
<html>
<head>
<meta charset="utf-8" />
<title>PHP 11</title>
</head>
<body>
<h1>PHP 11</h1>
<h2>Repaso SQL</h2>
<ul>
    <li><?php enlazar('sql3.sql', 'Tabla de países'); ?></li>
</ul>
<h2>Métodos estáticos en PHP</h2>
<ul>   
    <li><?php enlazar('clases6.php', 'Clase País'); ?></li>
    <li><?php enlazar('clases7.php', 'Ídem con objetos en array'); ?></li>
    <li><?php enlazar('clases8.php', 'Clase Mates con funciones estáticas'); ?></li>
    <li><?php enlazar('class-html.php', 'Clase HTML con funciones estáticas'); ?></li>
</ul>
</body>
</html>
