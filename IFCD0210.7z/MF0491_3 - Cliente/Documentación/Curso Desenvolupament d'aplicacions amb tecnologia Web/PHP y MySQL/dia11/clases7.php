<?php
/*
    http://localhost/dia11/clases7.php
*/    
    class Pais {
       
        private $nombre;
        private $poblacion;
        
        public function __construct($country, $habitantes) {
            $this->nombre = $country;
            $this->poblacion = $habitantes;
        }

        public function imprimir() {
            echo "El país {$this->nombre} tiene {$this->poblacion} habitantes<br>";
        }
        
    } // Fin  Pais
    
    $paises = array(
        new Pais('Francia', 66),
        new Pais('Italia', 60),
        new Pais('Grecia', 11),
        new Pais('Egipto', 82),
        new Pais('Marruecos', 33),
        new Pais('Perú', 30),
        new Pais('Uruguay', 3),
        new Pais('Australia', 23),
        new Pais('China', 1300),
        new Pais('India', 1100),
        new Pais('Japón', 127),
    );
    
    // Imprimir todos los países
    foreach($paises as $pais){
        $pais->imprimir(); 
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    