/*
    EJERCICIO DE REPASO DE SQL

    Escribe en SQL lo siguiente:
    
    1) Crea una tabla de paises
       con los campos: 
         id - Número entero, autonumérico y clave primaria
         pais - Texto de 32, obligatorio y sin repetir
         capital - Texto de 32
         poblacion - Número entero por defecto 0
         continente - Texto de 16
    2) Inserta los siguientes países:
         Europa:  Francia, Italia, Grecia
         África:  Egipto, Marruecos
         América: Perú, Uruguay
         Oceanía: Australia
         Asia:    China, India, Japón
    3) Incrementa la población de los países de África un 20%
    4) Borra China
    5) Haz una consulta que muestre todos los países 
       ordenados por continente y luego por país.
    6) Haz una consulta que muestre el pais y la población 
       de los países de Europa ordenado por población descendente.
    7) Una consulta que muestre: 'La capital de X es Y'
    8) Número de países y población total
    9) Ídem por continente
*/

USE bdacme;

-- 1
CREATE TABLE paises (
    id INT AUTO_INCREMENT,
    pais VARCHAR(32) NOT NULL,
    capital VARCHAR(32),
    poblacion INT DEFAULT 0,
    continente VARCHAR(16),
    --
    PRIMARY KEY (id),
    UNIQUE KEY pais (pais)
);

-- 2
INSERT INTO paises(id, pais, capital, poblacion, continente)
VALUES 
    (NULL, 'Francia', 'París', 66, 'Europa'),
    (NULL, 'Italia', 'Roma', 60, 'Europa'),
    (NULL, 'Grecia', 'Atenas', 11, 'Europa'),
    (NULL, 'Egipto', 'El Cairo', 82, 'África'),
    (NULL, 'Marruecos', 'Rabat', 33, 'África'),
    (NULL, 'Perú', 'Lima', 30, 'América'),
    (NULL, 'Uruguay', 'Montevideo', 3, 'América'),
    (NULL, 'Australia', 'Camberra', 23, 'Oceanía'),
    (NULL, 'China', 'Pekín', 1300, 'Asia'),
    (NULL, 'India', 'Nueva Delhi', 1100, 'Asia'),
    (NULL, 'Japón', 'Tokio', 127, 'Asia');
   
-- 3
UPDATE paises
SET poblacion = poblacion * 1.20
WHERE continente = 'África';

-- 4
DELETE FROM paises
WHERE pais = 'China'; 

-- 5
SELECT *
FROM paises
ORDER BY continente, pais;

-- 6
SELECT pais, poblacion
FROM paises
WHERE continente = 'Europa'
ORDER BY poblacion DESC;

-- 7
SELECT CONCAT('La capital de ',pais,' es ',capital) AS mensaje
FROM paises;
   
-- 8   
SELECT COUNT(*) AS cuenta, SUM(poblacion) AS total
FROM paises;

-- 9
SELECT continente, COUNT(*) AS cuenta, SUM(poblacion) AS total
FROM paises
GROUP BY continente;














