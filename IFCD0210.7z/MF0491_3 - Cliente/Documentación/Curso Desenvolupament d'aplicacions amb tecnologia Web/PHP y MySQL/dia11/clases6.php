<?php
/*
    http://localhost/dia11/clases6.php
*/
    
    class Pais {
       
        // Propiedades son las variables de la clase
        // son los datos que se almacenan cuando se cree el objeto
        private $nombre;
        private $poblacion;
        
        // Constructor
        // Inicializa las propiedades, dar un valor a las variables de la clase
        public function __construct($country, $habitantes) {
            $this->nombre = $country;
            $this->poblacion = $habitantes;
        }
        
        // Métodos
        // Funciones de la clase que pueden utilizar las variables de la clase
        public function imprimir() {
            echo "El país {$this->nombre} tiene {$this->poblacion} habitantes<br>";
        }
        
    } // Fin de la clase Pais
    
    // pais1 y pais2 son objetos de la clase Pais
    // Se reserva memoria del ordenador para almacenar los países
    $pais1 = new Pais('Portugal', 12000000);
    $pais2 = new Pais('Brasil', 64000000);
    
    //$pais1->nombre = 'Portugal'; // Error porque nombre es privado
    
    // Llamar a la función imprimir de cada objeto
    $pais1->imprimir();
    $pais2->imprimir();
    
    