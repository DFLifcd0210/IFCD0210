<?php
/*
    http://localhost/dia11/clases8.php
*/    
   
   class Mates {
             
       public static function sumar($a, $b) {
           return $a + $b;
       }       
       public static function restar($a, $b) {
           return $a - $b;
       }       
       public static function multiplicar($a, $b) {
           return $a * $b;
       }       
       public static function dividir($a, $b) {
           return $a / $b;
       }       
       public static function raiz($a) {
           return sqrt($a);
       }
       public static function cuadrado($a) {
           return pow($a,2); // CORREGIDO
       }
       public static function hipotenusa($cateto1, $cateto2) {
           return self::raiz(                
            self::sumar(
                self::cuadrado($cateto1),
                self::cuadrado($cateto2)
            )
          );
       }
       
   } // Fin Mates
   
   $c = Mates::sumar(23, 54);   
   echo "$c<br>";
   
   $c = Mates::restar(23, 54);   
   echo "$c<br>";
  
   $c = Mates::multiplicar(23, 54);   
   echo "$c<br>";  
 
   $c = Mates::dividir(23, 54);   
   echo "$c<br>";  
   
   $h = Mates::hipotenusa(23, 54);
   echo "$h<br>";
   
   $h = Mates::hipotenusa(4, 3);
   echo "$h<br>";  
    