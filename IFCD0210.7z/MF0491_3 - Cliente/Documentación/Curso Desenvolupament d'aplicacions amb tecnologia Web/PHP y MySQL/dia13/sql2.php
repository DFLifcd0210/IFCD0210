<?php
/*
   PHP (con PDO) y SQL (con MySQL)

   http://localhost/dia13/sql2.php
   
   
   1) Insertar 5 libros más
   
   2) Mostrar todos los libros por orden alfabético 
   
*/

$pdo = new PDO('mysql:host=localhost;dbname=bdacme','bdacme','bdacme');
$pdo->exec('SET CHARACTER SET utf8');

$pdo->exec("INSERT INTO libros(titulo, paginas, publicacion) VALUES
  ('La fundación', 250, '2014-05-07'),
  ('El señor de los anillos', 250, '2013-10-27'),
  ('El hobbit', 250, '2012-09-13'),
  ('Dune', 250, '2011-03-24'),
  ('El juego de Ender', 250, '2010-08-01')");
  
$datos = $pdo->query("SELECT * FROM libros ORDER BY titulo");
foreach($datos as $libro) {
    echo "<h2>".$libro['titulo']."</h2>";
    echo "<p>".$libro['publicacion']."</p>";
}
  
  