<?php   
/*
   http://localhost/dia13/sql3.php
   
   EJERCICIO:
     Crear una tabla de peliculas
     con los siguientes campos:
       id           - Número entero autonumérico y clave principal
       titulo       - Texto de 32, requerido y clave única
       año          - Número entero
       protagonista - Texto de 32
       precio       - Decimal de 8 cifras con 2 decimales
       
    Insertar 5 películas
    
    Incrementar el precio de las películas un 10%
    
    Borrar una película por su campo id
    
    Listar todas las películas ordenados por año en descendente  
*/   

// 1) Conexión con la base de datos

$pdo = new PDO('mysql:host=localhost;dbname=bdacme','bdacme','bdacme');

// 2) Mensajes en Unicode

$pdo->exec("SET CHARACTER SET utf8");

// 3) Crear la tabla

$pdo->exec("CREATE TABLE peliculas(
    id INT AUTO_INCREMENT,
    titulo VARCHAR(32) NOT NULL,
    año INT,
    protagonista VARCHAR(32),
    precio DECIMAL(8,2),
    PRIMARY KEY (id),
    UNIQUE KEY (titulo)
)");

// 4) Insertar datos 

$pdo->exec("INSERT INTO peliculas(id,titulo,año,protagonista,precio) VALUES
    (1, 'Ben-Hur', 1959, 'Charlton Heston', 13.5),
    (2, 'Interstellar', 2015, 'Matthew McConaughey', 25.5),
    (3, 'Fargo', 1996, 'Frances McDormand', 7.35),
    (4, 'Sopa de ganso', 1933, 'Groucho Marx', 5.25),
    (5, 'Matrix', 1999, 'Keanu Reeves', 17.6)
");

// 5) Actualizar datos

$pdo->exec("UPDATE peliculas 
SET precio = precio * 1.10
WHERE TRUE");

// 6) Borrar un registro

$pdo->exec("DELETE FROM peliculas
WHERE id = 5");

// 7) Consulta

$datos = $pdo->query("SELECT titulo, protagonista, precio, año
  FROM peliculas
  WHERE TRUE
  ORDER BY año DESC");
  
foreach($datos as $pelicula) {
    echo "<h2>$pelicula[titulo]</h2>";
    echo "<dl>";
    echo "<dt>Protagonista</dt><dd>$pelicula[protagonista]</dd>";
    echo "<dt>Año</dt><dd>$pelicula[año]</dd>";
    echo "<dt>Precio</dt><dd>$pelicula[precio]</dd>";
    echo "</dl>";
}  
  
  
  
  