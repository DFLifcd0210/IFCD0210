<?php
    require_once('../template.php');
?><!DOCTYPE html>
<html>
<head>
<meta charset="utf-8" />
<title>PHP 13</title>
</head>
<body>
<h1>PHP 13</h1>
<h2>Bases de datos con mediante PDO</h2>
<ul>
    <li><?php enlazar('sql1.php', 'Crear tabla libros', 'Insertar, modificar, borrar y consultar'); ?></li>
    <li><?php enlazar('sql2.php', 'Añadir 5 libros más'); ?></li>
    <li><?php enlazar('sql3.php', 'Crear tabla películas', 'Insertar, modificar, borrar y consultar'); ?></li>
</ul>
</body>
</html>
