<?php
/*
   PHP (con PDO) y SQL (con MySQL)

   http://localhost/dia13/sql1.php
   
*/

// 1) Conectar con la base de datos

$pdo = new PDO("mysql:host=localhost;dbname=bdacme", "bdacme", "bdacme");

// 2) Usar la codificación Unicode

$pdo->exec("SET CHARACTER SET utf8"); // Pon el juego de caracateres utf8

// 3) Crear la tabla

$pdo->exec("CREATE TABLE libros(
    id INT AUTO_INCREMENT,
    titulo VARCHAR(32) NOT NULL,
    paginas INT,
    publicacion DATE,
    PRIMARY KEY (id),
    UNIQUE KEY (titulo)
)");

// 4) Insertar datos en la tabla

$pdo->exec("INSERT INTO libros(id, titulo, paginas, publicacion) 
VALUES (1, 'La isla misteriosa', 650, '2015-02-20'),
       (2, 'El principito', 150, '2015-03-17'),
       (3, 'El Quijote', 1200, '2011-01-19'),
       (4, 'El perfume', 500, '2010-05-22'),
       (5, '1984', 450, '2009-08-11')");

// 5) Modificar datos

$pdo->exec("UPDATE libros SET titulo = UPPER(titulo) WHERE paginas > 500");

// 6) Borrar filas de la tabla

$pdo->exec("DELETE FROM libros WHERE id=5");

// 7) Realizar una consulta

$datos = $pdo->query("SELECT id, titulo, paginas
    FROM libros
    WHERE paginas >= 500
    ORDER BY paginas DESC");

foreach ($datos as $libro) {
    echo '<h2>'.$libro['titulo'].'</h2><p>'.$libro['paginas'].' págs.</p>';    
}    
    
    
    
    
