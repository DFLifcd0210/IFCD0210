<?php
/*
    Alternativas para acceder a la base de datos:
     - Funciones mysql_ = Sistema obsoleto
     - Funciones mysqli_ = Se puede usar como funciones o como clases
     - Clase PDO = Más genérico para cualquier base de datos
     - Funciones odbc_ = Es genérico 
*/
    try {
        $mensaje = '';
        $clase = '';
        $datos = array();
    
        // PASO 1: Realizar la conexión con el servidor de BD        
        $host = 'localhost';
        $database = 'bdacme';
        $user     = 'bdacme';
        $password = 'bdacme';    
        $cadenaConexion = "mysql:host=$host;dbname=$database";
        $db = new PDO($cadenaConexion, $user, $password);
        $db->exec("SET CHARACTER SET utf8");
        
        // PASO 2: Acceder a la tabla users
        $sql = "SELECT * FROM users";
        $datos = $db->query($sql, PDO::FETCH_ASSOC);  
    
    } 
    catch(PDOException $error) {       
        $mensaje = $error->getMessage();  
        $clase = 'error';        
    }   

    
?><!DOCTYPE>
<html>
<head>
  <meta charset="utf-8" />
  <title>Listado de usuarios</title>
  <link href="estilos.css" rel="stylesheet" />
</head>
<body class="<?php echo $clase;?>">
  <h1>Listado de usuarios</h1>
  <div id="mensaje"><?php echo $mensaje; ?></div>
  <?php  
    foreach ($datos as $fila) { // filas
        foreach ($fila as $campo) { // columnas
            echo $campo.', ';
        }
        echo '<br>';
    }  
  ?>  
</body>
</html>  






