<?php
 
    // http://localhost/dia08/index.php

?><!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8" />
  <title>Index</title>
  <link href="estilos.css" rel="stylesheet" />
</head>
<body class="publico">
    <h1>Index</h1>
    <p>Sólo se puede entrar en la zona privada tras iniciar sesión</p>
    <ul>
        <li><a href="privado1.php">Privado 1</a></li>
        <li><a href="login.php">Login</a></li>
    </ul>
</body>
</html>   