<?php

?><!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8" />
  <title>Prohibido</title>
  <link href="estilos.css" rel="stylesheet" />
</head>
<body class="prohibido">
    <h1>Prohibido</h1>
    <p>Acceso denegado a la zona privada</p>
    <ul>
        <li><a href="index.php">Index</a></li>        
    </ul>
</body>
</html>   