<?php
    session_start();
    if (!isset($_SESSION['connected'])) {
        header("Location: prohibido.php");
        exit();
    }

?><!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8" />
  <title>Privado 1</title>
  <link href="estilos.css" rel="stylesheet" />
</head>
<body class="privado">
    <h1>Privado 1</h1>
    <p>Has iniciado sesión como <strong><?php echo $_SESSION['user']; ?></strong></p>
    <ul>
        <li><a href="index.php">Index</a></li>
        <li><a href="logout.php">Logout</a></li>
    </ul>
</body>
</html>   