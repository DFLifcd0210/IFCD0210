<?php
    session_start();
    
    $mensaje = "Inicia sesión para acceder a la zona privada";
    $usuario = "";
    $clave = "";
  
    if (!empty($_POST)) {
        $usuario = $_POST['user'];
        $clave = $_POST['password'];
        if (conexionCorrecta($usuario, $clave)) {
            $_SESSION['connected'] = "on";
            $_SESSION['user'] = $usuario;     
            header("Location: privado1.php");
            exit();
        }
        else {
            $mensaje = "ERROR: Usuario o contraseña incorrecto";
        }
    }
  
    function conexionCorrecta ($usuario, $clave) {
        $usuarios = array(
            'pepe'=> "123",
            'ana'=> "123",
            'alex'=> "456",
        ); 
        if (isset($usuarios[$usuario])) { // Existe la clave usuario en el array?
            return $usuarios[$usuario] == $clave; // La contraseña coincide?
        }
        else {
            return false;
        }
    }

?><!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8" />
  <title>Login</title>
  <link href="estilos.css" rel="stylesheet" />
</head>
<body class="publico">
    <h1>Login</h1>
    <p><?php echo $mensaje; ?></p>
    <form method="POST" action="login.php">
      <input type="hidden" name="login" value="on" />
      <input type="text" name="user" 
        value="<?php echo $usuario; ?>"
        placeholder="Usuario"  
        maxlength="16" 
        title="pepe o ana"
        autofocus="on"
        />
      <input type="password" name="password" 
        placeholder="Contraseña" 
        maxlength="32" 
        title="123" />
      <input type="submit" value="Iniciar sesión" />
    </form>
    <ul>
        <li><a href="index.php">Index</a></li>        
    </ul>
</body>
</html>   