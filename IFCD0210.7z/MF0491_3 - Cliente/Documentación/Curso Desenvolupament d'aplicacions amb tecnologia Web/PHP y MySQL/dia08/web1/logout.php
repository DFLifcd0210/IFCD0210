<?php

    session_start();
    session_unset();

?><!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8" />
  <title>Logout</title>
  <link href="estilos.css" rel="stylesheet" />
</head>
<body class="privado">
    <h1>Logout</h1>
    <p>Has cerrado la conexión</p>
    <ul>
        <li><a href="index.php">Index</a></li>        
    </ul>
</body>
</html>   