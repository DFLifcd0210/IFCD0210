<?php
/*
    http://localhost/dia05/funciones6.php   
*/

// ----------------------------------------------
// Llamar a las funciones

repetirFrase("Más vale pájaro en mano que ciento volando", 5);
repetirFrase("Más vale arte que maña", 10);

echo repetirFraseV2("Agua pasada no mueve molino", 5);
echo repetirFraseV2("El saber no ocupa lugar", 10);

// ----------------------------------------------
// Declarar las funciones

function repetirFrase ($frase, $cantidad) {
    for ($i=0; $i<$cantidad; $i++) {
        echo "$frase<br>";
    }  
}

function repetirFraseV2 ($frase, $cantidad) {
    $lineas = array();    
    for ($i=0; $i<$cantidad; $i++) {
        $lineas[] = $frase;
    }
    return implode('<br>', $lineas).'<br>';
}


