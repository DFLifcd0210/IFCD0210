<?php
/*
    1) Crea un array vacío.
    2) Añade al array 100 números aleatorios.
       Cada número aleatorio está entre 1 y 49.
    3) Ordena el array.
    4) Imprime todos los elementos del array
       separados por coma.
*/

// Paso 1
$primitiva = array();

// Paso 2
for ($i=0; $i<100; $i++) {
    // Añadir un número al final del array
    $primitiva[] = rand(1, 49);
}

// Paso 3
sort($primitiva);

// Paso 4
foreach ($primitiva as $numero) {
    echo "$numero, ";
}


