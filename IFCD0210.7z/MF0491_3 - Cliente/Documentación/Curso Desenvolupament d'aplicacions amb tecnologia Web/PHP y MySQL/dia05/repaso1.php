<?php
/*
REPASO DE ARRAYS

Crea un array asociativo 
con una lista de enlaces:

CLAVE   ENLACE
Google  http://www.google.com
Drive   http://drive.google.com
GMail   http://mail.google.com
Maps    http://maps.google.com

Imprime la lista de enlaces usando
las etiquetas <ul> <li> <a>
*/
$enlaces = array(
    'Google'=> "http://www.google.com",
    'Drive'=> "http://drive.google.com",
    'GMail'=> "http://mail.google.com",
    'Maps'=> "http://maps.google.com",
);

echo "<ul>\n";
foreach ($enlaces as $clave=>$valor) {   
   echo "<li><a href=\"$valor\">$clave</a></li>\n";
}
echo "</ul>\n";




