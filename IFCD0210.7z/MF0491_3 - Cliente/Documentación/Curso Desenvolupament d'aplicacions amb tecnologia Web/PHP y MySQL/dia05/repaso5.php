<?php
/*
    Generar 7 números de la primitiva
    sin que haya duplicados
    
    Generar muchos números de primitiva:
        12 34 11 12 17 22 33 41 43 ...
    
    Quitar duplicados y quedarnos con los 7 primeros:
        12 34 11 17 22 33 41
*/

// Genera 100 números de primitiva
//   12 34 11 22 17 22 33 41 43 11 ...
$primitiva = array();
for ($i=0; $i<100; $i++) {    
    $primitiva[] = rand(1, 49);
}
$primitiva = array_unique($primitiva);
$primitiva = array_slice($primitiva, 0, 7); 
sort($primitiva);
echo implode(", ", $primitiva);

