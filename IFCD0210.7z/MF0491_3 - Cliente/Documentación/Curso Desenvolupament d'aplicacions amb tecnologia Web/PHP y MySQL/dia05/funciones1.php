<?php
/*
    http://localhost/dia05/funciones1.php
    
    Funciones:
        - Declarar la función
        - Usar la función
*/

function imprimeTitulo () {
    echo "<h1>Vehículo</h1>";
    echo "<ul>";
    echo "<li>Monopatín</li>";
    echo "<li>Patinete</li>";
    echo "</ul>";
}


imprimeTitulo();
imprimeTitulo();
imprimeTitulo();









    

