<?php
/*
    Generar 7 números de la primitiva
    sin que haya duplicados
    
    Generar muchos números de primitiva:
        12 34 11 12 17 22 33 41 43 ...
    
    Quitar duplicados y quedarnos con los 7 primeros:
        12 34 11 17 22 33 41
*/

// Genera 100 números de primitiva
$primitiva = array();
for ($i=0; $i<100; $i++) {    
    $primitiva[] = rand(1, 49);
}

// Quita los valores duplicados
$primitiva = array_unique($primitiva);

/*
 // Puede dar error si accedes a un índice que no existe
  0=> 23
  1=> 17
  2=> 23 --- Este elemento queda elemento por el array_unique
  3=> 41
  etc.  
 for ($i=0; $i<7; $i++) {
   echo $numero[$i].", "; 
 }
*/

// Coger los 7 primeros números
$cuenta = 0;
foreach ($primitiva as $numero) {
    echo $numero.", ";
    $cuenta++;
    if ($cuenta == 7) break;
}



