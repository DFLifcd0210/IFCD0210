<?php
/*
    http://localhost/dia05/funciones4.php
*/

// ----------------------------------------------
// Llamar a las funciones

$trio = sumaTrio(5,7,11);
echo "$trio<br>"; // 23

$titulo = encabezado('Programación');
echo $titulo; // <h1>Programación</h1>

// ----------------------------------------------
// Declarar las funciones

function sumaTrio ($num1, $num2, $num3) {
    $suma = $num1 + $num2 + $num3;
    return $suma;
}

function encabezado ($texto) {
    $html = "<h1>$texto</h1>";
    return $html;
}
