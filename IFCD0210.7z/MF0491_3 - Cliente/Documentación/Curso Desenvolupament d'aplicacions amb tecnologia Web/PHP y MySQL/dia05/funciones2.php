<?php
/*
    http://localhost/dia05/funciones2.php
*/

// Declarar la función SUMA
function suma($numero1, $numero2) {
    $resultado = $numero1 + $numero2;
    echo "$numero1 + $numero2 = $resultado<br>";
}

// Declarar la función MULTIPLICAR
function multiplicar($numero1, $numero2) {
    $resultado = $numero1 * $numero2;
    echo "$numero1 por $numero2 es $resultado<br>";
}

// Llamar a la función SUMA
suma(123,67);
suma(55,8);
suma(44,15);

// Llamar a la función MULTIPLICAR
multiplicar(23,423);
multiplicar(3,5);



    

