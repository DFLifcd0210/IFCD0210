<?php
/*
    http://localhost/dia05/funciones5.php
    
    3.1416
    pi()
    M_PI
    
    Longitud = 2 * Radio * PI
*/

// ----------------------------------------------
// Llamar a las funciones


$longitud = circulo(23); // Radio
echo "La longitud del círculo es $longitud<br>";


echo enlace('Google', "http://www.google.com"); 
// Imprime <a href="http://www.google.com">Google</a>


// ----------------------------------------------
// Declarar las funciones

function circulo ($radio) {
    $largo = 2 * $radio * M_PI;
    return $largo;
}

function enlace ($texto, $vinculo) {
    $a = "<a href=\"$vinculo\">$texto</a>";
    return $a;
}






