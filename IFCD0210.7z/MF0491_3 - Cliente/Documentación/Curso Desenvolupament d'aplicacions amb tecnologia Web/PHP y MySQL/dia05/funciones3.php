<?php
/*
    http://localhost/dia05/funciones3.php
*/

// Declarar la función SUMA
function suma($numero1, $numero2) {    
    // La variable $resultado es local a la función
    $resultado = $numero1 + $numero2;
    return $resultado;
}

// Declarar la función MULTIPLICAR
function multiplicar($numero1, $numero2) {
    $resultado = $numero1 * $numero2;
    return $resultado;    
}

// Llamar a la función

suma(5,8); // El valor devuelto se pierde

echo suma(2,6).'<br>'; // El valor devuelto se imprime

$valor = suma(11,23); // El valor devuelto se guarda en una variable
echo $valor.'<br>'; 

$total = suma(suma(1,2), suma(3,4)); // El valor final es 10
echo $total.'<br>'; 

if (suma(1,3) == 4) { // En un IF
    echo "es cuatro";
}
else {
    echo "no es cuatro";
}











    

