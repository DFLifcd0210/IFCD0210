<?php
	$nombre = "Pepe";
	$telefono = "555-67-89-01";
	
	$mensaje = 
		"El teléfono de ". 
		$nombre.
		" es ".
		$telefono;
		
	echo $mensaje;
?>