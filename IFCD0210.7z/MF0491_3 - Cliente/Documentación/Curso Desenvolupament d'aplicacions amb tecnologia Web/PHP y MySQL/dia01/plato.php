<?php
	/*
	$nombre = "Paella";
	$principal = "arroz bomba";
	$tiempo = "60 minutos";
	*/	
	$nombre = "Pizza";
	$principal = "harina";
	$tiempo = "20 minutos";

?><!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8" />
		<title><?php echo $nombre; ?></title>
	</head>
	<body>
		<h1><?php echo $nombre; ?></h1>
		<p>El ingrediente principal es
			<?php echo $principal; ?>
		</p>
		<p>El tiempo de preparación es 
			<?php echo $tiempo; ?>
		</p>
	</body>
</html>