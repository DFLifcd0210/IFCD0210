<?php
	/*
		Programa que multiplica
		dos n�meros
		
		23-3-2015 - Francisco Cascales
	*/

	$numero1 = 23;
	$numero2 = 17;
	$resultado = $numero1 * $numero2;
	echo $resultado;
?>	


