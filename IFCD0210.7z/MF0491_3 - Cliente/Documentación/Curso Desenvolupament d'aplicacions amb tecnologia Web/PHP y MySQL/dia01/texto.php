<?php
	/*
		Para que salgan bien los 
		acentos el Notepad++ ha 
		de usar UTF-8
	*/
	$nombre = "Francisco";
	$saludo = "Buenos días";
	
	$mensaje = $saludo . " " . $nombre;
	
	echo $mensaje;
?>