<?php

	// Crea la variable $a
	// y le asigna el valor 135
	$a = 135;
	
	$b = 89;
	
	$c = $a + $b;

	echo $c;
?>