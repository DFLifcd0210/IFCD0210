<?php
/*
	La capital de X es Y y tiene Z habitantes
*/
	$nombre = "Francia";
	$capital = "París";
	$habitantes = 54000000;
	
	$mensaje = "La capital de <b>$nombre</b> es <b>$capital</b> y tiene <b>$habitantes</b> habitantes";
		
	echo $mensaje;
?>