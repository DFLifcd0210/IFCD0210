<?php
/*
	La capital de X es Y y tiene Z habitantes
*/
	$nombre = "Francia";
	$capital = "París";
	$habitantes = 54000000;
	
	$mensaje = "La capital de $nombre es $capital y tiene $habitantes habitantes";
		
	echo $mensaje;
?>