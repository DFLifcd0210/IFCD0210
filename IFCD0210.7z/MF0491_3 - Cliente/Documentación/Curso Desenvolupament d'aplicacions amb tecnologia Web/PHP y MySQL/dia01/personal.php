<?php
	$color  = $_GET['color'];
	$edad   = $_GET['edad'];
	$musica = $_GET['musica'];
	
?><!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8" />
  <title>Personal</title>
</head>
<body>
  <h1>Personal</h1>
  <p>Tu color preferido es el <?php echo $color; ?></p>
  <p>Tu edad es <?php echo $edad; ?> años</p>
  <p>Te gusta la música <?php echo $musica; ?></p>
  <hr />
  <h2>Enlaces</h2>
  <ul>
	<li><a href="personal.php?color=rojo&edad=18&musica=pop">Uno</a></li>
	<li><a href="personal.php?color=azul&edad=27&musica=rock">Dos</a></li>
	<li><a href="personal.php?color=cian&edad=36&musica=new+age">Tres</a></li>
	<li><a href="personal.php?color=añil&edad=45&musica=country">Cuatro</a></li>
  </ul> 
</body>  
</html>




