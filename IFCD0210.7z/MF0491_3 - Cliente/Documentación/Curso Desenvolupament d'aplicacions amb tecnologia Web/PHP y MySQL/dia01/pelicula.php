<?php

	/*
	$titulo = "Blade Runner";
	$director = "Ridley Scott";
	$estrella = "Harrison Ford";
	$cartel = "blade_runner.jpg";
	*/
	
	$titulo = "Alien, el octavo pasajero";
	$director = "Ridley Scott";
	$estrella = "Sigourney Weaver";
	$cartel = "alien.jpg";

?><!DOCTYPE html>
<html>
<head>
<meta charset="utf-8" />
<title><?php echo $titulo; ?></title>
</head>
<body>
<p><img width="128" src="imgs/<?php echo $cartel; ?>" /></p>
<h1><?php echo $titulo; ?></h1>
<p>Está dirigida por <strong><?php echo $director; ?></strong></p>
<p>Está protagonizada por <strong><?php echo $estrella; ?></strong></p>
</html>