<?php
/*  http://localhost/dia10/clases5.php
    
    Añadir una nueva variable: opacidad
*/

    class Rectangulo {
        
        private $left;
        private $top;
        private $width;
        private $height;
        private $bgcolor;
        private $opacity;
        
        public function __construct($x, $y, $ancho, $alto, $color) {
            $this->left = $x;
            $this->top = $y;
            $this->width = $ancho;
            $this->height = $alto;
            $this->bgcolor = $color;
            $this->opacity = 1;
        }
        
        public function setColor($color) {
            $this->bgcolor = $color;
        }        
        public function setOpacity($opacidad) {
            $this->opacity = $opacidad;
        }
        
        public function imprimir() {
            echo "El rectángulo está en la posición {$this->left},{$this->top}
          tiene un tamaño de {$this->width}&times;{$this->height} píxeles,
          es de color {$this->bgcolor} y la opacidad es {$this->opacity}<br />";
        }
        
        public function dibujar() {
            echo "<div style=\"position:absolute; left:{$this->left}px; top:{$this->top}px; width:{$this->width}px; height:{$this->height}px; background-color:{$this->bgcolor};opacity:{$this->opacity};\">Rectángulo</div>";
        }        
        
    } // End Rectangulo
    
    $r1 = new Rectangulo(100,200, 300,400, 'red');
    $r2 = new Rectangulo(200,300, 100,100, 'green');
    $r3 = new Rectangulo(200,50, 50,100, 'blue'); 
    
    $r1->setOpacity(0.5);
    $r3->setOpacity(0.7);
    
    $r1->setColor('#0FF'); // Cyan
    $r2->setColor('#FF0'); // Yellow    
    
        
?><!DOCTYPE html>
<html>    
<head>
  <title>Rectángulos</title>
  <meta charset="utf8" />
</head>
<body>
    <h1>Rectángulos</h1>
    <?php 
        $r1->imprimir();
        $r2->imprimir();
        $r3->imprimir();
        
        $r1->dibujar();
        $r2->dibujar();
        $r3->dibujar();
    ?>
</body>
</html>  
    
    
    
    
    
    
    
    