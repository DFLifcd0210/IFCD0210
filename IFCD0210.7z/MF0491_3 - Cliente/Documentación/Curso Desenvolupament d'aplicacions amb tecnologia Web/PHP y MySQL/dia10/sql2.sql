-- sql2.sql

USE bdacme;

/*
    Crear 2 tablas relacionadas entre sí
    La tabla pedidos y detalles de pedidos
*/
CREATE TABLE pedidos(
    id INT AUTO_INCREMENT,
    cliente VARCHAR(32) NOT NULL,
    fecha DATE NOT NULL, -- 'yyyy-mm-dd'
    iva INT DEFAULT 21,
    --
    PRIMARY KEY (id)
);

CREATE TABLE detalles(
    id INT AUTO_INCREMENT,
    id_pedido INT, -- Clave externa: se refiera al id de pedidos
    producto VARCHAR(32) NOT NULL,
    precio DECIMAL(8,2) DEFAULT 0,
    cantidad INT DEFAULT 1,
    --
    PRIMARY KEY (id),
    KEY id_pedido (id_pedido) -- Índice que agiliza las búsquedas
);

-- INSERTAR NUEVOS REGISTROS

INSERT INTO pedidos(id, cliente, fecha, iva) VALUES 
  (100, 'Aristóteles', '2015-04-08', 21),
  (200, 'Platón', '2015-04-08', 10),
  (300, 'Socrates', '2015-04-09', 21);
  
INSERT INTO detalles(id, id_pedido, producto, precio, cantidad) VALUES
  (1, 100, 'lápiz', 1.5, 100),
  (2, 100, 'bloc', 3, 20),
  --
  (3, 200, 'lápiz', 0.5, 250),
  (4, 200, 'cuaderno', 4, 10),
  --
  (5, 300, 'bolígrafo', 2, 50),
  (6, 300, 'clips', 1.5, 15);
  
SELECT *
FROM pedidos;

SELECT * 
FROM detalles;  

-- MODIFICAR LOS DATOS 

UPDATE pedidos 
SET fecha = '2015-04-07'
WHERE id = 100;

UPDATE pedidos
SET iva = 19
WHERE iva = 21;
  
-- BORRAR FILAS  

DELETE FROM pedidos 
WHERE id = 300;

DELETE FROM detalles
WHERE id_pedido = 300;

-- CONSULTAS

SELECT precio, producto
FROM detalles
WHERE id_pedido = 100
ORDER BY precio DESC;

SELECT cliente, iva
FROM pedidos
WHERE iva > 15
ORDER BY cliente;

-- CONSULTA DE VARIAS TABLAS

SELECT p.cliente, d.producto
FROM pedidos p
  INNER JOIN detalles d ON d.id_pedido = p.id;
  
SELECT p.id, d.id, p.cliente, d.producto
FROM pedidos p
  INNER JOIN detalles d ON d.id_pedido = p.id;  

SELECT *
FROM pedidos p
  INNER JOIN detalles d ON d.id_pedido = p.id
WHERE p.id = 200;  

SELECT id, id_pedido, producto, precio, cantidad,
   precio * cantidad AS importe
FROM detalles;   

SELECT p.id, d.producto, d.precio, d.cantidad, p.iva,
   ROUND(d.precio * d.cantidad * (1 + p.iva/100), 2) AS total
FROM detalles d
  INNER JOIN pedidos p ON p.id = d.id_pedido;  

SELECT p.id, 
  ROUND(SUM(d.precio * d.cantidad * (1 + p.iva/100)), 2) AS total
FROM detalles d
  INNER JOIN pedidos p ON p.id = d.id_pedido
GROUP BY p.id;



