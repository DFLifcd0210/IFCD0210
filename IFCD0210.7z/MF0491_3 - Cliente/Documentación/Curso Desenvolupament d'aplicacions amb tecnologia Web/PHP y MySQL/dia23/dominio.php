<?php
// http://localhost/php/dia23/dominio.php

/*
  Escribe el dominio actual de esta página
  En mi ordenador pone: localhost
  Si la subo a Nixiweb pondrá: -----.uni.me
*/

  echo "<br />El nombre del servidor es: <strong>";
  echo $_SERVER['HTTP_HOST'];
  echo "</strong><br />";
  
  echo "<br />El navegador web es: <strong>";
  echo $_SERVER['HTTP_USER_AGENT'];
  echo "</strong><br />";
  
  echo "<br />Los idiomas del navegador web son: <strong>";
  echo $_SERVER['HTTP_ACCEPT_LANGUAGE'];
  echo "</strong><br />";
  
  
  
  