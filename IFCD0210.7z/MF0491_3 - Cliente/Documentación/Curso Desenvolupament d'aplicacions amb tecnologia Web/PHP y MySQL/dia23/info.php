<?php
// http://localhost/php/dia23/info.php

  phpinfo();