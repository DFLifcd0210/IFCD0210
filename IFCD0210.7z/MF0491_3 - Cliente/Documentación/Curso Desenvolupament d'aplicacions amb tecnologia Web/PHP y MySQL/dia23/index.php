<?php
    require_once('../template.php');
?><!DOCTYPE html>
<html>
<head>
<meta charset="utf-8" />
<title>PHP 23</title>
</head>
<body>
<h1>PHP 23</h1>
<h2>Dominio y hospedaje</h2>
<ul>
    <li><?php enlazar('dominio_hospedaje.txt', 'Apuntes de dominio, hospedaje y FTP'); ?></li>    
    <li><?php enlazar('info.php', 'Obtener toda la información del PHP', 'Función phpinfo'); ?></li>    
    <li><?php enlazar('dominio.php', 'Ídem al detalle', 'HTTP_HOST, HTTP_USER_AGENT, HTTP_ACCEPT_LANGUAGE'); ?></li>    
</ul>

</body>
</html>
