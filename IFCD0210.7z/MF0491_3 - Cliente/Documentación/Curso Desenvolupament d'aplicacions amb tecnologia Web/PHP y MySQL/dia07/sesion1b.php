<?php
// http://localhost/dia07/sesion1b.php

    session_start();

    echo "<h1>Obtener la variable</h1>";
    
    echo $_SESSION['autor'];