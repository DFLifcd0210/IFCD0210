<?php
/*
    http://localhost/dia07/calculadora.php
    
    Crear una calculadora que opere con 2 números y dé 1 resultado
    Las operaciones son: Sumar, Restar, Multiplicar y Dividir.
    
    Hacer un formulario con los siguientes campos:
      - operando1 - INPUT text name="operando1"
      - operando2 - INPUT text name="operando2"
      - botón sumar       - INPUT submit name="operador" value="Sumar"
      - botón restar      - INPUT submit name="operador" value="Restar"
      - botón multiplicar - INPUT submit name="operador" value="Multiplicar"
      - botón dividir     - INPUT submit name="operador" value="Dividir"
      - resultado - INPUT text readonly
*/

    // Inicializar las variables
    $operando1 = '45';
    $operando2 = '';
    $operador = '';
    $resultado = '';
    
    if (!empty($_POST)) {
        // Leer los datos envíados
        $operando1 = floatval($_POST['operando1']);
        $operando2 = floatval($_POST['operando2']);
        $operador = $_POST['operador'];       
    }
    
    if (empty($operando2) && $operador == 'Dividir') {
        $resultado = 'ERROR: División entre 0';
    }
    else {    
        switch ($operador) {
            case 'Sumar':       $resultado = $operando1 + $operando2; break;
            case 'Restar':      $resultado = $operando1 - $operando2; break;
            case 'Multiplicar': $resultado = $operando1 * $operando2; break;        
            case 'Dividir':     $resultado = $operando1 / $operando2; break;
        }
    }

?><!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8" />
  <title>Calculadora</title>
</head>
<body>
  <h1>Calculadora</h1>
  <form method="POST" action="calculadora.php">
    <p>
      <input type="text" name="operando1" placeholder="Operando 1"
            value="<?php echo $operando1; ?>" />
      <br />
      <input type="text" name="operando2" placeholder="Operando 2"
            value="<?php echo $operando2; ?>" />
    </p>
    <p>
      <input type="submit" name="operador" value="Sumar" />
      <input type="submit" name="operador" value="Restar" />
      <input type="submit" name="operador" value="Multiplicar" />
      <input type="submit" name="operador" value="Dividir" />
    </p>
    <p>
      <input type="text" name="resultado" placeholder="Resultado" readonly
            value="<?php echo $resultado; ?>" />
    </p>
  </form>
</body>
</html>








