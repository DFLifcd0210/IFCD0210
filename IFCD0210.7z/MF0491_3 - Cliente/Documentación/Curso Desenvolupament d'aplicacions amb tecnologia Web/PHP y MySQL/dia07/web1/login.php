<?php

    // http://localhost/dia07/login.php

    session_start();
    session_unset(); //$_SESSION = array();
    
    $mensaje = '';
    
    if (!empty($_POST)) {
        $user = $_POST['user'];
        $password = $_POST['password'];
        
        if ($user == 'pepe' && $password == '123') {
            $_SESSION['conectado'] = 'on';
            $_SESSION['usuario'] = $user;
            header('Location: privado.php');
        }
        else {
            $mensaje = "Nombre de usuario o contraseña incorrecto";
        }        
    }
    
    
?><!DOCTYPE html>
<html>
<head>
  <title>Login</title>
  <meta charset="utf-8" />
  <?php include 'estilos.php'; ?>
</head>
<body>
  <h1>Login</h1>
  <p><?php echo $mensaje; ?></p>
  <form method="POST" action="login.php">
     <p>
        <input type="text" name="user" placeholder="Usuario" maxlength="8" />
        <br />
        <input type="password" name="password" placeholder="Contraseña" />
     </p>
     <p>
        <input type="submit" value="Iniciar sesión" />
     </p>
  </form>
  <p>NOTA: El usuario es 'pepe' y la contraseña es '123'</p>
  
  <?php include 'menu.php'; ?>
  
  <!-- Comentario HTML -->
</body>
</html>








