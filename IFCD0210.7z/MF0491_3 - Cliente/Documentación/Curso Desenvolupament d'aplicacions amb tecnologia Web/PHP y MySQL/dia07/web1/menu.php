  <p>
    <a href="login.php">Login</a><br />
    <a href="privado.php">Privado</a><br />
    <a href="secreto.php">Secreto</a><br />
    <a href="vip.php">VIP</a>
  </p>
  <p>
     &copy; 2014-<?php echo date('Y'); ?>
  </p>
  