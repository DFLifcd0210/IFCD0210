<style>
  body { 
    margin:0 2em; 
    font-family:Verdana; 
    background-color:#cfc;
  }
  a {
    color:#0c0;
    text-decoration:none;
  }
  a:hover {
    text-decoration:underline;
  }
</style>