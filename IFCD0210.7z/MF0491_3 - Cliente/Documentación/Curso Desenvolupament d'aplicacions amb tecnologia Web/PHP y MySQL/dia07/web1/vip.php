<?php

    // http://localhost/dia07/privado.php
    
    session_start();   
    
    if (!isset($_SESSION['conectado'])) {
        header('Location: login.php');        
    }    
    
?><!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8" />
  <title>Página VIP</title>
  <?php include 'estilos.php'; ?>
</head>
<body>
  <h1>Página VIP</h1>
  <p>Nombre de usuario: <?php echo $_SESSION['usuario']; ?></p>
  
  <p>Bla, bla, bla...</p>
  <p>Cosas de VIP...</p>
  <p>Bla, bla, bla...</p>
  
    <?php include 'menu.php'; ?>

</body>
</html>    