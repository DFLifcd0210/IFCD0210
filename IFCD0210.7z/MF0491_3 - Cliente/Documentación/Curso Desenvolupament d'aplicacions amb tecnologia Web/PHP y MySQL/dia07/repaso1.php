<?php
/*
    http://localhost/dia07/repaso1.php
  
    EJERCICIO:
    
        Crear un formulario "repaso1.html"    
            Un formulario que pida 2 campos: el nombre y la edad
            
        Crear una página PHP "repaso1.php"
            Mostrar el mensaje "X tiene Y años"  
*/

if (empty($_POST)) {
    header("Location: repaso1.html");
    exit();
}

$nombre = $_POST['nombre'];
$edad = $_POST['edad'];

echo "$nombre tiene $edad años";