<?php
// http://localhost/dia07/sesion1a.php

    session_start();

    echo "<h1>Poner la variable</h1>";
    
    //$autor = "Pepito"; //Sólo funciona en esta página
    
    $_SESSION['autor'] = "Pepito";
    
?>
<p><a href="sesion1b.php">Siguiente paso</a></p>    