<?php
/*
    http://localhost/dia07/repaso2.php
*/

$mensaje = '';
$nombre = '';
$edad = '';

if (!empty($_POST)) {
    $nombre = $_POST['nombre'];
    $edad = $_POST['edad'];
    
    if (empty($nombre) || empty($edad)) {
        $mensaje = "Falta el nombre o la edad";
    }
    else {
        $mensaje = "$nombre tiene $edad años";
    }
}

?><!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8" />
  <title>Nombre y edad</title>
</head>
<body>
  <h1>Nombre y edad</h1>
  
  <p><?php echo $mensaje; ?></p>
  
  <form method="POST" action="repaso2.php">
    <p>
        <label for="nombre">Nombre</label><br />
        <input type="text" id="nombre" name="nombre"
            placeholder="Nombre" value="<?php echo $nombre; ?>" />
    </p>
    <p>
        <label for="edad">Edad</label><br />
        <input type="text" id="edad" name="edad"
            placeholder="Edad" value="<?php echo $edad; ?>" />
    </p>
    <p>
        <input type="submit" value="Enviar" />
    </p>
  </form>
</body>
</html>