<?php
    // http://localhost/dia18/enlaces.php
    $datos = array();

    require_once "../conexion.php";
    $acme = new PDO("mysql:host=$servidor;dbname=$basedatos", $usuario, $clave);
    $acme->exec("SET CHARACTER SET utf8");

    $datos = $acme->query("SELECT * FROM enlaces ORDER BY id DESC");

?><!DOCTYPE html>
<html>
<head>
  <title>Enlaces</title>
  <meta charset="utf-8" />
  <link href="enlaces.css" rel="stylesheet" />
</head>
<body>
  <header>
    <h1>Enlaces</h1>
  </header>
  <section>
    <?php foreach($datos as $fila): ?>
    <article>
        <p><a href="<?php echo $fila['enlace']; ?>">
           <?php echo htmlspecialchars($fila['titulo']); ?>
        </a></p>
        <p><?php echo $fila['enlace']; ?></p>
        <p><?php echo htmlspecialchars($fila['comentario']); ?></p>
    </article>
    <?php endforeach; ?>
  </section>
  <footer>
    <p>Acme &copy; 2015</p>
  </footer>
</body>
</html>
