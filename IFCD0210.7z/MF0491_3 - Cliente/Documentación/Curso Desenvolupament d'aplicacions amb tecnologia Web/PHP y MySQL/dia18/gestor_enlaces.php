<?php
    // http://localhost/php/dia18/gestor_enlaces.php

    $datos = array();

    require_once "../conexion.php";
    $acme = new PDO("mysql:host=$servidor;dbname=$basedatos", $usuario, $clave);
    $acme->exec("SET CHARACTER SET utf8");

    $datos = $acme->query("SELECT * FROM enlaces ORDER BY id DESC");

?><!DOCTYPE html>
<html>
<head>
  <title>Gestor de enlaces</title>
  <meta charset="utf-8" />
  <link href="privado.css" rel="stylesheet" />
</head>
<body>
    <h1>Gestor de enlaces</h1>
    <table>
    <tr>
        <th>Título</th>
        <th>Enlace</th>
        <th>Comandos</th>
    </tr>
    <?php foreach($datos as $fila): ?>
      <tr>
        <td><?php echo htmlspecialchars($fila['titulo']); ?></td>
        <td><?php echo $fila['enlace']; ?></td>
        <td>
            <a href="modificar_enlace.php?id=<?php echo $fila['id']; ?>">Modificar</a> |
            <a href="borrar_enlace.php?id=<?php echo $fila['id']; ?>">Borrar</a>
        </td>
      </tr>
    <?php endforeach; ?>
    </table>
    <p>
        <a href="insertar_enlace.php">Insertar un nuevo enlace</a>
    </p>
    <p>
        <a href="enlaces.php">Ver página pública</a>
    </p>
</body>
</html>
