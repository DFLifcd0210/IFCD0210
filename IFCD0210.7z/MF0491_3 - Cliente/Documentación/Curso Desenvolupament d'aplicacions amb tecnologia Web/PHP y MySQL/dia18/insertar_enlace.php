<?php
    // http://localhost/php/dia18/insertar_enlace.php

    require_once "../conexion.php";
    $acme = new PDO("mysql:host=$servidor;dbname=$basedatos", $usuario, $clave);
    $acme->exec("SET CHARACTER SET utf8");

    // Inicializar las variables que se muestran en el HTML
    $mensaje = '';
    $titulo = '';
    $enlace = '';
    $comentario = '';

    if (!empty($_POST)) {

        // Recuperar los datos introducidos por el usuario
        $titulo = trim($_POST['titulo']);
        $enlace = trim($_POST['enlace']);
        $comentario = trim($_POST['comentario']);

        // Comprobar que los datos sean correctos
        if (empty($titulo))     { $mensaje .= 'Falta el título<br>';     }
        if (empty($enlace))     { $mensaje .= 'Falta el enlace<br>';     }
        if (empty($comentario)) { $mensaje .= 'Falta el comentario<br>'; }

        // Si no hay mensaje de error insertamos el comentario en la BD
        if (empty($mensaje)) {
            $plantilla = $acme->prepare("INSERT INTO enlaces(titulo,enlace,comentario) VALUES (?,?,?)");
            if ($plantilla->execute(array($titulo, $enlace, $comentario))) {
               header("Location: gestor_enlaces.php");
            }
            else {
               $mensaje = "ERROR: No pude insertar";
            }
        }
    }

?><!DOCTYPE html>
<html>
<head>
  <title>Insertar enlace</title>
  <meta charset="utf-8" />
  <link href="privado.css" rel="stylesheet" />
</head>
<body>
    <h1>Insertar enlace</h1>

    <p><?php echo $mensaje; ?></p>

    <form action="insertar_enlace.php" method="post">
       <p>
          <label>Título</label>
          <input type="text" name="titulo" value="<?php echo htmlspecialchars($titulo); ?>" />
       <p>
       <p>
          <label>Enlace</label>
          <input type="text" name="enlace" value="<?php echo htmlspecialchars($enlace); ?>"/>
       </p>
       <p>
          <label>Comentario</label>
          <textarea name="comentario"><?php echo htmlspecialchars($comentario); ?></textarea>
       </p>
       <p>
          <input type="submit" value="Insertar" />
       </p>
    </form>

    <p><a href="gestor_enlaces.php">Gestor de enlaces</a></p>

</body>
</html>
