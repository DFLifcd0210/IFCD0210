<?php
    require_once('../template.php');
?><!DOCTYPE html>
<html>
<head>
<meta charset="utf-8" />
<title>PHP 18</title>
</head>
<body>
<h1>PHP 18</h1>
<h2>Tabla enlaces: Gestor de contenidos completo</h2>
<ul>
    <li><?php enlazar('enlaces_ejercicio.txt', 'Enunciado del ejercicio'); ?></li>
    <li><?php enlazar('enlaces.sql', 'Base de datos'); ?></li>
    <li><?php enlazar('enlaces.php', 'Página pública'); ?></li>
    <li><?php enlazar('enlaces.css', 'Estilos'); ?></li>
    <li><?php enlazar('gestor_enlaces.php', 'Gestor de enlaces'); ?></li>
    <li><?php enlazar('insertar_enlace.php', 'Insertar nuevo enlace'); ?></li>
    <li><?php enlazar('borrar_enlace.php', 'Borrar enlace existente'); ?></li>
    <li><?php enlazar('modificar_enlace.php', 'Modificar un enlace'); ?></li>
</ul>

</body>
</html>
