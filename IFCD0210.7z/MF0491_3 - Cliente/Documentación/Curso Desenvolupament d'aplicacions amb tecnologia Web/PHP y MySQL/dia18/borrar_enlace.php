<?php
    // http://localhost/php/dia18/borrar_enlace.php

    require_once "../conexion.php";
    $acme = new PDO("mysql:host=$servidor;dbname=$basedatos", $usuario, $clave);
    $acme->exec("SET CHARACTER SET utf8");

    // Inicializar las variables que se muestran en el HTML
    $mensaje = '';
    $id = '';

    if (!empty($_GET)) { // Vengo del gestor de contenidos
        $id = $_GET['id'];
    }
    elseif (!empty($_POST)) { // He pulsado el botón del formulario
        $id = $_POST['id'];
        $plantilla = $acme->prepare("DELETE FROM enlaces WHERE id = ?");
        if ($plantilla->execute(array($id))) {
            header("Location: gestor_enlaces.php");
        }
        else {
            $mensaje = "ERROR: No pude borrar";
        }
    }
    else {
        $mensaje = "ERROR: Falta el id";
    }

?><!DOCTYPE html>
<html>
<head>
  <title>Borrar enlace</title>
  <meta charset="utf-8" />
  <link href="privado.css" rel="stylesheet" />
</head>
<body>
    <h1>Borrar enlace</h1>

    <p><?php echo $mensaje; ?></p>

    <form action="borrar_enlace.php" method="post">
       <input type="hidden" name="id" value="<?php echo $id; ?>" />
       <p>
          <input type="submit" value="Borrar" />
       </p>
    </form>

    <p><a href="gestor_enlaces.php">Gestor de enlaces</a></p>
</body>
</html>
