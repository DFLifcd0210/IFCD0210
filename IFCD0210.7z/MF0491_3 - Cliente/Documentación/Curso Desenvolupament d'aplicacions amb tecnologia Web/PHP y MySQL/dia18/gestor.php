<?php
  session_start();

  require_once "../conexion.php";
  $bd = new PDO("mysql:host=$servidor;dbname=$basedatos", $usuario, $clave);
  $bd->exec("SET CHARACTER SET utf8");

  $tabla = '';
  $accion = '';
  $titulo = '';
  $datos = array();

  if (!empty($_GET)) {

  }




?><!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8" />
  <title><?php echo "$titulo $tabla"; ?></title>
</head>
<body>
  <p id="mensaje" class="<?php echo $class; ?>"><?php echo $mensaje; ?></p>
  <h1><?php echo "$titulo $tabla"; ?></h1>
  <?php if($accion == 'list'): ?>
    <table>
    <?php
      $list = file_get_contents($tabla."_list.html");
    ?>
    <?php foreach($campos as $campo):

    <?php endforeach; ?>
    </table>
    <p><a href="">Insertar</a></p>
  <?php else: ?>
    <form action="gestor.php" method="POST">
      <input type="hidden" name="id" value="<?php echo $id; ?>" />
      <input type="hidden" name="accion" value="<?php echo $accion; ?>" />
      <input type="hidden" name="tabla" value="<?php echo $tabla; ?>" />
      <?php
        if ($accion != 'delete'):
          $form = file_get_contents($tabla."_form.html");
        endif;
      ?>
      <p><input type="submit" value="<?php echo ""; ?>" /></p>
    </form>
    <p><a href="">Gestor</a></p>
  <?php endif; ?>
</body>
</html>
