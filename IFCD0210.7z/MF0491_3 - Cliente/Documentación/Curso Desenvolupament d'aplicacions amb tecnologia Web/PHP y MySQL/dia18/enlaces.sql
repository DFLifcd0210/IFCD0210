/* enlaces.sql

   Crea la tabla enlaces e inserta 2 enlaces.
   
   Pasos a seguir:
    1) Abrir http://localhost/phpmyadmin
    2) Seleccionar la base de datos "bdacme"
    3) Importar este archivo SQL 
*/

CREATE TABLE enlaces(
    id          INT AUTO_INCREMENT,
    titulo      VARCHAR(128) NOT NULL,
    enlace      VARCHAR(128) NOT NULL,
    comentario  TEXT,
    PRIMARY KEY (id)
);

INSERT INTO enlaces(titulo, enlace, comentario) 
VALUES
    ('Primero', 'http://es.wikipedia.org', 'Comentarios varios'),
    ('Segundo', 'http://ca.wikipedia.org', 'Más cosas');