<?php
    // http://localhost/php/dia18/modificar_enlace.php

    require_once "../conexion.php";
    $acme = new PDO("mysql:host=$servidor;dbname=$basedatos", $usuario, $clave);
    $acme->exec("SET CHARACTER SET utf8");

    // Inicializar las variables que se muestran en el HTML
    $mensaje = '';
    $id = '';
    $titulo = '';
    $enlace = '';
    $comentario = '';

    if (!empty($_GET)) { // Vengo del gestor de contenidos
        $id = $_GET['id'];

        // Recuperar la información de la base datos
        $plantilla = $acme->prepare('SELECT * FROM enlaces WHERE id = ?');
        $plantilla->execute(array($id));
        $datos = $plantilla->fetch();

        $titulo = $datos['titulo'];
        $enlace = $datos['enlace'];
        $comentario = $datos['comentario'];
    }
    elseif (!empty($_POST)) { // He pulsado el botón del formulario

        // Recuperar los datos introducidos por el usuario
        $id = $_POST['id'];
        $titulo = trim($_POST['titulo']);
        $enlace = trim($_POST['enlace']);
        $comentario = trim($_POST['comentario']);

        // Comprobar que los datos sean correctos
        if (empty($titulo))     { $mensaje .= 'Falta el título<br>';     }
        if (empty($enlace))     { $mensaje .= 'Falta el enlace<br>';     }
        if (empty($comentario)) { $mensaje .= 'Falta el comentario<br>'; }

        // Si no hay mensaje de error modificar el comentario en la BD
        if (empty($mensaje)) {
            $plantilla = $acme->prepare("UPDATE enlaces SET titulo = ?, enlace = ?, comentario = ? WHERE id = ?");
            if ($plantilla->execute(array($titulo, $enlace, $comentario, $id))) {
               $mensaje = "Actualización realizada correctamente";
            }
            else {
               $mensaje = "ERROR: No pude modificar";
            }
        }
    }
    else {
        $mensaje = "ERROR: Falta el id";
    }

?><!DOCTYPE html>
<html>
<head>
  <title>Modificar enlace</title>
  <meta charset="utf-8" />
  <link href="privado.css" rel="stylesheet" />
</head>
<body>
    <h1>Modificar enlace</h1>

    <p><?php echo $mensaje; ?></p>

    <form action="modificar_enlace.php" method="post">
       <input type="hidden" name="id" value="<?php echo $id; ?>" />
       <p>
          <label>Título</label>
          <input type="text" name="titulo" value="<?php echo htmlspecialchars($titulo); ?>" />
       <p>
       <p>
          <label>Enlace</label>
          <input type="text" name="enlace" value="<?php echo htmlspecialchars($enlace); ?>"/>
       </p>
       <p>
          <label>Comentario</label>
          <textarea name="comentario"><?php echo htmlspecialchars($comentario); ?></textarea>
       </p>
       <p>
          <input type="submit" value="Modificar" />
       </p>
    </form>

    <p><a href="gestor_enlaces.php">Gestor de enlaces</a></p>

</body>
</html>
